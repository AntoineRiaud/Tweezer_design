import Load_material 
import numpy
import math
from scipy.linalg import eig as scipy_eig
import matplotlib.pyplot as plt
import transformations
from plot3D_colormap import plot_on_sphere


def bulk_wave_dispersion_relation(alpha,beta,gamma,orientation_type = 'rzxz',wave_type = 'L',substrate_filename = None, plot = False):
    #alpha = numpy.deg2rad(90.); beta = numpy.deg2rad(90.); gamma = numpy.deg2rad(0.) #Y-Z cut
    #alpha = numpy.deg2rad(0.); beta = numpy.deg2rad(-90.); gamma = numpy.deg2rad(90.) #Z-X cut
    #alpha = numpy.deg2rad(0.); beta = numpy.deg2rad(0.); gamma = numpy.deg2rad(0.) #X-Y cut
    R = transformations.euler_matrix(alpha, beta, gamma, orientation_type)
    m = Load_material.load_material_gui(material_filename = substrate_filename)
    C = Load_material.Voigt2tensor(m['C'])
    e = Load_material.Voigt2tensor(m['e'])
    rho = m['rho']
    eps = m['eps']
    #normalization
    ##C = C/1e9
    ##eps = eps/(8.85e-12)
    ##rho = rho/1000

    n_psi = 100
    n_sigma = 100
    i = range(n_psi)
    j = range(n_sigma)
    psi = numpy.array(i)*math.pi/n_psi 
    sigma = numpy.array(j)*math.pi/n_sigma #numpy.deg2rad(90)# for validation 
    psi,sigma = numpy.meshgrid(psi,sigma)
    slowness = []
    displ = []

    for i in range(psi.shape[0]):
        for k in range(psi.shape[1]):
            lx = numpy.cos(psi[i,k])*numpy.sin(sigma[i,k])
            ly = numpy.sin(psi[i,k])*numpy.sin(sigma[i,k])
            lz = numpy.cos(sigma[i,k])
            l = numpy.array([lx,ly,lz])#numpy.concatenate((lx,ly,lz),axis = 2)
            l = numpy.dot(R[:3,:3],l)
            #print('eps.shape')
            #print(eps.shape)
            l_il_j = numpy.outer(l,l)
            #equations from Peach On the Existence of Surface Acoustic Waves on Piezoelectric Substrates,
            #ieee transactions on ultrasonics, ferroelectrics, and frequency control, vol. 48, no. 5, september 2001
            C_ijkll_jl_l  = numpy.tensordot(C,l_il_j,axes=([3,1],[1,0]))
            e_kijl_k_l_j = numpy.atleast_2d(numpy.tensordot(e,l_il_j,axes=([0,2],[0,1]))).T
            e_ijkl_i_l_k = numpy.atleast_2d(numpy.tensordot(e,l_il_j,axes=([0,2],[0,1])))
            eps_ijl_i_l_j = numpy.atleast_2d(numpy.tensordot(eps,l_il_j,axes=([0,1],[0,1])))
    ##        print('C_ijkll_jl_l.shape')
    ##        print(C_ijkll_jl_l)
    ##        print('e_kijl_k_l_j.shape')
    ##        print(e_kijl_k_l_j)
    ##        print('e_ijkl_i_l_k.shape')
    ##        print(e_ijkl_i_l_k)
    ##        print('eps_ijl_i_l_j.shape')
    ##        print(eps_ijl_i_l_j)
            Atop = numpy.concatenate((C_ijkll_jl_l,e_kijl_k_l_j),axis=1)
            Abottom = numpy.concatenate((e_ijkl_i_l_k,-eps_ijl_i_l_j),axis=1)
            A = numpy.concatenate((Atop,Abottom),axis=0)
            #print('A shape')
            #print(A)
            B = numpy.diag([1.]*3+[0])*rho
            #print(B)
            s2,v = scipy_eig(A, b=B,left = False,right = True)
    ##        for i in range(4):
    ##            try:
    ##                print('i = '+str(i))
    ##                print(numpy.dot(A,v[:,i])-s2[i]*numpy.dot(B,v[:,i]))
    ##            except ValueError:
    ##                print('ValueError for v = '+str(v[:,i].tolist()))
            s = numpy.sqrt(numpy.real(s2))
            ind = numpy.argsort(s)
            s = s[ind]
            v = v[:,ind]
            s2 = s2[ind]
    ##        for i in range(4):
    ##            try:
    ##                print('i = '+str(i))
    ##                print(numpy.dot(A,v[:,i])-s[i]**2*numpy.dot(B,v[:,i]))
    ##            except ValueError:
    ##                print('ValueError for v = '+str(v[:,i].tolist()))
            slowness.append(1/s[0:3])
            displ.append(v)

    n = numpy.dot(numpy.linalg.inv(R[:3,:3]),[0,0,1])
    wave_index = {'T2':0,'T1':1,'L':2}
    slowness = numpy.reshape(numpy.real(numpy.array(slowness)[:,wave_index[wave_type]]),sigma.shape,order = 'C')
    U = numpy.reshape(numpy.array(displ)[:,wave_index[wave_type],0],sigma.shape,order = 'C')
    V = numpy.reshape(numpy.array(displ)[:,wave_index[wave_type],1],sigma.shape,order = 'C')
    W = numpy.reshape(numpy.array(displ)[:,wave_index[wave_type],2],sigma.shape,order = 'C')
    Phi = numpy.reshape(numpy.array(displ)[:,wave_index[wave_type],3],sigma.shape,order = 'C')
    norm2plot = numpy.sqrt(numpy.abs(U)**2+numpy.abs(V)**2+numpy.abs(W)**2+numpy.abs(Phi)**2)
    #displ2plot = numpy.abs(U)/norm2plot #V for Y cut
    displnormal = U*n[0]+V*n[1]+W*n[2]
    displ2plot = numpy.abs(displnormal)/norm2plot


    if plot:
        #need to define the displacement. So far all the calculations are in the viewpoint of the wave (longi and transverse motion).
        #then use list comprehension K = [x for x in mylist]
        plt.imshow(slowness)
        plt.colorbar()
        plt.xlabel('longitude')
        plt.ylabel('lattitude')
        plot_on_sphere(sigma[:,0]+1e-6,psi[0,:]+1e-6,slowness,slowness)
        #ax = plt.subplot(111, projection='polar')        
        #ax.plot(numpy.ravel(psi), slowness)
        plt.show()



    


    return({'psi': psi, 's_Ray': slowness, 'sigma': sigma, 'a': displ2plot})
