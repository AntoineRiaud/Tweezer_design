from scipy.interpolate import RectSphereBivariateSpline
import numpy as np
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt
from matplotlib.colorbar import ColorbarBase, make_axes_gridspec

#http://stackoverflow.com/questions/33569225/attaching-intensity-to-3d-plot

def plot_on_sphere(theta,phi,r,c):
    #creates a finer grid
    theta_itp = np.linspace(0, np.pi, 100)
    phi_itp = np.linspace(0, 2 * np.pi, 100)
    # evaluate spline fit on a denser 50 x 50 grid of thetas and phis
    if type(r)!=float:
        splr = RectSphereBivariateSpline(theta, phi, r)
    splc = RectSphereBivariateSpline(theta, phi, c)
    if type(r)==float:
        r_itp = r
    else:
        r_itp = splr(theta_itp, phi_itp)    
    c_itp = splc(theta_itp, phi_itp)

    x_itp = r_itp * np.outer(np.sin(theta_itp), np.cos(phi_itp)) #Cartesian coordinates of sphere
    y_itp = r_itp * np.outer(np.sin(theta_itp), np.sin(phi_itp))
    z_itp = r_itp * np.outer(np.cos(theta_itp), np.ones_like(phi_itp))

    norm = plt.Normalize()
    facecolors = plt.cm.jet(norm(c_itp))
    # surface plot
    fig, ax = plt.subplots(1, 1, subplot_kw={'projection':'3d', 'aspect':'equal'})
    ax.hold(True)
    ax.plot_surface(x_itp, y_itp, z_itp, rstride=1, cstride=1, facecolors=facecolors)

    #Colourbar
    cax, kw = make_axes_gridspec(ax, shrink=0.6, aspect=15)
    cb = ColorbarBase(cax, cmap=plt.cm.jet, norm=norm)
    cb.set_label('Voltage', fontsize='x-large')


    plt.show()


r = 0.1648 
theta = np.array([0.503352956, 1.006705913, 1.510058869, 1.631533785, 2.134886741, 2.638239697]) #Our theta vals
phi = np.array([np.pi/4, np.pi/2, 3*np.pi/4, np.pi, 5*np.pi/4, 3*np.pi/2, 7*np.pi/4, 2*np.pi]) #Our phi values

v = np.array([0.002284444388889,0.003155555477778,0.002968888844444,0.002035555555556,0.001884444411111,0.002177777733333,0.001279999988889,0.002666666577778,0.015777777366667,0.006053333155556,0.002755555533333,0.001431111088889,0.002231111077778,0.001893333311111,0.001288888877778,0.005404444355556,0,0.005546666566667,0.002231111077778,0.0032533332,0.003404444355556,0.000888888866667,0.001653333311111,0.006435555455556,0.015311110644444,0.002453333311111,0.000773333333333,0.003164444366667,0.035111109822222,0.005164444355556,0.003671111011111,0.002337777755556,0.004204444288889,0.001706666666667,0.001297777755556,0.0026577777,0.0032444444,0.001697777733333,0.001244444411111,0.001511111088889,0.001457777766667,0.002159999944444,0.000844444433333,0.000595555555556,0,0,0,0]) #Lists 1A-H, 2A-H,...,6A-H
volt = np.reshape(v, (6, 8))

plot_on_sphere(theta,phi,r,volt)




