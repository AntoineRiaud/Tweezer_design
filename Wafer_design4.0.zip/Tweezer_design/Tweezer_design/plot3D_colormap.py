from scipy.interpolate import RectSphereBivariateSpline
import numpy as np
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt
from matplotlib.colorbar import ColorbarBase, make_axes_gridspec

#http://stackoverflow.com/questions/33569225/attaching-intensity-to-3d-plot

def plot_on_sphere_itp(theta,phi,r,c):
    #creates a finer grid
    theta_itp = np.linspace(0, np.pi, 100)
    phi_itp = np.linspace(0, 2 * np.pi, 100)
    # evaluate spline fit on a denser 50 x 50 grid of thetas and phis
    if type(r)!=float:
        splr = RectSphereBivariateSpline(theta, phi, r)
    splc = RectSphereBivariateSpline(theta, phi, c)
    if type(r)==float:
        r_itp = r
    else:
        r_itp = splr(theta_itp, phi_itp)    
    c_itp = splc(theta_itp, phi_itp)

    x_itp = r_itp * np.outer(np.sin(theta_itp), np.cos(phi_itp)) #Cartesian coordinates of sphere
    y_itp = r_itp * np.outer(np.sin(theta_itp), np.sin(phi_itp))
    z_itp = r_itp * np.outer(np.cos(theta_itp), np.ones_like(phi_itp))

    norm = plt.Normalize()
    facecolors = plt.cm.jet(norm(c_itp))
    # surface plot
    fig, ax = plt.subplots(1, 1, subplot_kw={'projection':'3d', 'aspect':'equal'})
    ax.hold(True)
    ax.plot_surface(x_itp, y_itp, z_itp, rstride=1, cstride=1, facecolors=facecolors)

    #Colourbar
    cax, kw = make_axes_gridspec(ax, shrink=0.6, aspect=15)
    cb = ColorbarBase(cax, cmap=plt.cm.jet, norm=norm)
    cb.set_label('Voltage', fontsize='x-large')


    plt.show()

def plot_on_sphere(theta,phi,r,c):

    x_itp = r * np.outer(np.sin(theta), np.cos(phi)) #Cartesian coordinates of sphere
    y_itp = r * np.outer(np.sin(theta), np.sin(phi))
    z_itp = r * np.outer(np.cos(theta), np.ones_like(phi))

    norm = plt.Normalize()
    facecolors = plt.cm.jet(norm(c))
    # surface plot
    fig, ax = plt.subplots(1, 1, subplot_kw={'projection':'3d', 'aspect':'equal'})
    ax.hold(True)
    ax.plot_surface(x_itp, y_itp, z_itp, rstride=1, cstride=1, facecolors=facecolors)

    #Colourbar
    cax, kw = make_axes_gridspec(ax, shrink=0.6, aspect=15)
    cb = ColorbarBase(cax, cmap=plt.cm.jet, norm=norm)
    cb.set_label('Voltage', fontsize='x-large')


    plt.show()

def scatter_easy(x,y,z,color):
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')
    ax.scatter(x, y, z, c = color, marker='o')
    ax.set_xlabel('x')
    ax.set_ylabel('y')
    ax.set_zlabel('z')
    plt.jet()
    plt.show()

