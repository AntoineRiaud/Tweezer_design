import geometry2 as geom2

class Transducer:
    def __init__(self,parameters,substrate):
        self.parameters = parameters
        self.substrate = substrate
        self.generation_method = geom2.generation_method[
                                parameters['Finger_type']]
        #specifies IDT/SPUDT/split IDT etc
        self.fingers = self.generation_method(parameters,substrate)

class Finger_cell:
    generation_method = {'IDT':Finger_cell.IDT,'SPUDT':Finger_cell.SPUDT}

    def __init__(self,substrate,parameters):
        self.

    def IDT:
        

class Finger(dict):
    def __init__(self,substrate,parameters):
        #sets the generation method. The 'transducer_type' field indicates
        #if it is a bulk wave transducer or a SAW transducer, if it is plane wave
        #or vortex or something else
        self.generatrix = geom2.generatrix_function[
                                parameters['transducer_type']]
        self.polygons = self.generatrix.buffer(parameters)
        



##########################ex. for GEOM2#################################
generation_method = {}
