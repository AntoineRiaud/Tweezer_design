# -*- coding: utf-8 -*-
"""
Created on Tue Mar 15 12:25:02 2016

@author[code]: Antoine Riaud
@coauthors: Michael Baudoin, Jean-Louis Thomas, Olivier Bou Matar
IEMN - Institut d'Electronique, Microelectronique et Nanotechnologies
INSP - Institut des Nanosciences de Paris 
"""

#function summary
# Default_properties[Debug] emulates the properties of a piezo material

#import goes here
import math
import numpy
import shapely.geometry as shapely_geom
import shapely.affinity as shapely_affinity
import shapely.ops as shapely_ops
import Shapely_extension #modifies the buffer function to enable variable width
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from filtered_der import periodic_derivative
import sphere_derivation as sphd
from descartes import PolygonPatch
from figures import BLUE, RED, GREY
from copy import deepcopy
import scipy.io as sio
import gdsCAD as gds
import svg_toolbox as SVGT
#import tkMessageBox
import tkinter.messagebox as tkMessageBox
from matplotlib import cm
from scipy.interpolate import RectSphereBivariateSpline,UnivariateSpline
from scipy.optimize import broyden1,broyden2,excitingmixing,linearmixing,minimize
from plot3D_colormap import plot_on_sphere,scatter_easy
#from progressbar import *               # just a simple progress bar
from scipy.optimize.nonlin import NoConvergence
try:
    import cPickle as pickle
except:
    import pickle
import warnings
from progress.bar import Bar
import spherepy


#material properties import
def Default_properties(anisotropy_factor):
    plot=False
    n_psi = 100
    i = range(n_psi)
    psi = numpy.array(i)*math.pi/n_psi
    s_Ray = 1/(4500*(1+anisotropy_factor*numpy.sin(2*psi)))
    a = numpy.ones(n_psi)
    a[25:]=-1
    if plot:
        ax = plt.subplot(111, projection='polar')
        ax.plot(psi.tolist(), s_Ray.tolist(), color='r', linewidth=3)
        ax.set_rmax(max(s_Ray))
        ax.grid(True)
        
        ax.set_title("Slowness curve", va='bottom')
        plt.show(block = False)
    return({'psi': psi, 's_Ray': s_Ray, 'a': a})

def Default_properties_3D(s0,anisotropy_factor):
    #for spherical harmonics
    #''You must have a full set of data over the surface of a sphere. The sigma coordinate runs 0 to pi radians from the
    #  north to south poles, and corresponds to the rows of
    #  the NumPy array. The psi coordinate runs from 0 to 2*pi - 2*
    #  pi / ncols radians, and corresponds to the colums of the NumPy array.''
    plot=False
    n_psi = 20
    n_sigma = 20
    i = range(n_psi)
    j = range(n_sigma)
    psi = numpy.array(i)*math.pi/n_psi #in [0 pi[, later filled by symmetry
    sigma = numpy.array(j)*math.pi/(n_sigma-1) #in [0 pi]
    psi,sigma = numpy.meshgrid(psi,sigma)
    s_Ray = s0*(1+anisotropy_factor*numpy.sin(2*psi)*numpy.sin(sigma)) #1+Y^1_1
    a = numpy.ones([n_psi,n_sigma])
    #a[25:,25:]=-1
    if plot:
        kxkykz = spher2cart(psi, sigma, s_Ray)
        kx = kxkykz[0,:,:]
        ky = kxkykz[1,:,:]
        kz = kxkykz[2,:,:]
        ax = plt.subplot(111, projection='3d')
        ax.plot_surface(kx,ky, kz, color = 'b', rstride=4, cstride=4)
        #ax.set_rmax(max(s_Ray))
        #ax.grid(True)
        ax.set_title("Slowness surface", va='bottom')
        plt.show(block = False)
    return({'psi': psi, 's_Ray': s_Ray, 'sigma': sigma, 'a': a})

def cart2pol(xy):
    x = xy[:,0]
    y = xy[:,1]
    rho = numpy.sqrt(x**2 + y**2)
    phi = numpy.arctan2(y, x)
    return(rho, phi)

def pol2cart(phi,rho):
    x = rho * numpy.cos(phi)
    y = rho * numpy.sin(phi)
    xy = numpy.vstack((x,y)).T
    return(xy)

def cart2spher(xyz):
    x = xyz[0,:,:]
    y = xyz[1,:,:]
    z = xyz[2,:,:]
    rho = numpy.sqrt(x**2 + y**2 + z**2)
    r = numpy.sqrt(x**2 + y**2)
    phi = numpy.arctan2(y, x)
    theta = numpy.arctan2(z, r)
    return(rho, phi, theta)

def spher2cart(phi, theta, rho):
    x = rho * numpy.cos(phi)* numpy.sin(theta)
    y = rho * numpy.sin(phi)* numpy.sin(theta)
    z = rho * numpy.cos(theta)
    xyz = numpy.dstack((x,y,z)).T
    return(xyz)

def Degeneration_correction(z,slowness,s_Ray,psi):
    # z and slowness are numpy arrays
    # the 0th dimension is for the propagation angle psi
    # the 1st dimension is for the material layer
    plot=False
    slowness = numpy.atleast_2d(slowness)
    z = numpy.atleast_2d(z)
    #s_Ray2 = numpy.atleast_2d(s_Ray)
    if z.size <=1:
        mu_0 = 0*psi
    else:
        if slowness.shape[0]==len(psi):      
            sz = numpy.sqrt(slowness**2 - numpy.tile(s_Ray**2,(slowness.shape[1],1)).T)
            dz = numpy.diff(z)
            dz = numpy.tile(dz,(psi.size,1))
            mu_0 = numpy.sum(dz*sz,1)
        else:
            sz = numpy.sqrt(numpy.tile(slowness**2,(s_Ray.size,1)) - numpy.tile(s_Ray**2,(slowness.size,1)).T)
            mu_0 = numpy.sum(numpy.diff(z,1,1)*sz,1)
    if plot:
        ax = plt.subplot(111, projection='polar')
        ax.plot(psi.tolist(), mu_0.tolist(), color='r', linewidth=3)
        ax.set_rmax(max(mu_0))
        ax.grid(True)
        ax.set_title("Correction", va='bottom')
        plt.show(block = False)
    return(mu_0)

def Degeneration_correction_3D(z,z0,slowness,s_Ray,psi,sigma): #TODO - must check
    # z and slowness are numpy arrays
    # the 0th dimension is for the propagation angle psi
    # the 1st dimension is for the material layer
    plot=False
    slowness = numpy.atleast_3d(slowness) #shape (N,) yields (1,N,1), shape (M,N) yields (M,N,1)
    z = numpy.atleast_3d(z)
    s_Ray_r = s_Ray*numpy.sin(sigma) #projection of s_Ray on the x-y plane.
    #s_Ray2 = numpy.atleast_2d(s_Ray)
    if z.size <=1:
        mu_0 = 0.*psi
    else: #note that the discotinuity of sz near sigma=pi/2 is NOT accounted for,
        #the reason is that the devices are supposed to be designed for sigma <0 and we want to avoid filtering
        if slowness.shape[0]==len(psi) & slowness.shape[1]==len(sigma):      #slowness[psi,sigma,medium]
            sz = numpy.sign(numpy.pi/2-sigma)*numpy.sqrt(slowness**2 - numpy.tile(s_Ray_r**2,(slowness.shape[2],1,1)).T)#sz(sigman)
            dz = numpy.diff(z)
            dz = numpy.tile(dz,(psi.size,2))
            mu_0 = numpy.sum(dz*sz,1)/(max(z.flat)-z0)
        else: #slowness[1,medium,1] due to atleast_3d
            sz = numpy.tile(numpy.sign(numpy.pi/2-sigma),(slowness.shape[1],1,1)
                            ).transpose(1,2,0)*numpy.sqrt(numpy.tile(slowness.transpose(0,2,1)**2,(s_Ray.shape[0],s_Ray.shape[1],1))
                            - numpy.tile(s_Ray_r**2,(slowness.shape[1],1,1)).transpose(1,2,0))
            mu_0 = numpy.zeros_like(sz[:,:,0])
            layer=0
            for dz in numpy.diff(z,1,1).flat:
                mu_0 += dz*sz[:,:,layer]
                layer += 1
            mu_0 = mu_0/(max(z.flat)-z0)
    if numpy.isnan(mu_0).any():
        tkMessageBox.showwarning(title = 'Warning',message = 'Substrate_slowness is too high')
        raise ValueError('high value of substrate slowness results in sqrt(-1) and crashes mu_0')
    if plot:
        mu_0c = sphd.AngSpectrum(mu_0, lattitude = sigma, longitude = psi, Nmax = 6)
        mu_0c.plot_direct
    return(mu_0,sz)

def Mesh_Theta(target_size,omega,mu_0,s_Ray,N_turns,l,electrodes_angle):
    freq = omega/(2*numpy.pi)
    lambda_approx = 1/(freq*numpy.mean(s_Ray))
    R0 = target_size + omega*numpy.mean(mu_0)*lambda_approx/(2*numpy.pi)
    if l==0:
        Theta = []
        phi_0 = 2*numpy.pi*R0/lambda_approx
        for n in range(N_turns):
            Theta_max = 2*numpy.pi
            R_approx = R0+n*lambda_approx
            dTheta = lambda_approx/(6*R_approx)
            Theta.append(numpy.arange(electrodes_angle[0],Theta_max+electrodes_angle[0],dTheta))
    else:
        Theta_max = 2*numpy.pi*numpy.ceil(N_turns/numpy.absolute(l))
        Theta = [electrodes_angle[0]]
        while Theta[-1]<(electrodes_angle[0]+Theta_max):
            R_approx = R0+numpy.abs(l)*Theta[-1]*lambda_approx/(2*numpy.pi)
            dTheta = lambda_approx/(6*R_approx)
            Theta.append(Theta[-1]+dTheta)
        if l<0:
            Theta = Theta[::-1]
            phi_0 = numpy.abs(l)*(Theta[0]+2*numpy.pi*R0/lambda_approx)
        else:
            phi_0 = (2*numpy.pi*R0/lambda_approx)
    return {'Theta':Theta,'phi_0':phi_0}

def Mesh_Theta_3D(target_size,omega,s_Ray,N_turns,l,z,z0,electrodes_angle,mu0):#TODO - must check
    freq = omega/(2*numpy.pi)
    s_Ray_avg = numpy.mean(s_Ray)
    lambda_approx = 1/(freq*s_Ray_avg)
    R0 = target_size/2
    Zn = max(z)-z0
    if l==0:
        R0min = -z0+Zn*numpy.max(mu0)/s_Ray_avg+0.5*lambda_approx
    else:
        R0min = -z0+Zn*numpy.max(mu0)/s_Ray_avg-numpy.abs(l)*electrodes_angle[0]*lambda_approx/(2*numpy.pi)+0.5*lambda_approx
    R0min*=1.1
    R0 = max([R0,R0min])
    if R0 == R0min:
        warnings.warn('target size is too small, original value is '
                      +str(target_size*1000.)+' mm but it has to be changed to '
                      +str(2*R0min*1000.) + ' mm.')
    if l==0:
        Theta = []
        Theta0 = 2*numpy.pi*R0/lambda_approx
        for n in range(N_turns):
            Theta_max = 2*numpy.pi
            R_approx = numpy.sqrt((R0+n*lambda_approx)**2-Zn**2)
            dTheta = lambda_approx/(6*R_approx)
            Theta.append(numpy.arange(electrodes_angle[0],Theta_max+electrodes_angle[0],dTheta))
    else:
        Theta_max = 2*numpy.pi*numpy.ceil(N_turns/numpy.absolute(l))
        Theta = [electrodes_angle[0]]
        while Theta[-1]<(electrodes_angle[0]+Theta_max):
            R_approx = numpy.sqrt((R0+numpy.abs(l)*Theta[-1]*lambda_approx/(2*numpy.pi))**2-Zn**2)
            dTheta = lambda_approx/(6*R_approx)
            Theta.append(Theta[-1]+dTheta)
        if l<0:
            Theta = Theta[::-1]
            Theta0 = numpy.abs(l)*(Theta[0]+2*numpy.pi*R0/lambda_approx)
        else:
            Theta0 = (2*numpy.pi*R0/lambda_approx)
    return {'Theta':Theta,'Theta0':Theta0,'target_size':2*R0}



def thickness_factor(electrode_type):
    return {
        'IDT':1.0,
        'snail':1.0,
        'snail_2':1.0,
        'splitIDT':0.5
    }[electrode_type]



def IDT_Master_Curve(psi,Theta,mu_0,s_Ray,l,omega,phi_0,a):
    plot = False
    save = False  

    sprime_Ray = periodic_derivative(psi,s_Ray,16)
    cos_beta = s_Ray/numpy.sqrt(s_Ray**2+sprime_Ray**2)
    sin_beta = sprime_Ray/numpy.sqrt(s_Ray**2+sprime_Ray**2)
    beta = numpy.arctan2(sin_beta,cos_beta)
    psibar_Theta = Theta+numpy.interp(Theta,psi,beta,period = 2*numpy.pi)
    Num1 = numpy.interp(Theta,psi,-mu_0*omega,period=2*numpy.pi)
    Num2 = l*psibar_Theta #numpy.array(Theta), there is a mistake in the thesis
    Num3r = numpy.interp(psibar_Theta,psi,+1.0*numpy.real(a),period=2*numpy.pi)
    Num3i = numpy.interp(psibar_Theta,psi,+1.0*numpy.imag(a),period=2*numpy.pi)
    if numpy.sum(Num3r**2)>10*numpy.sum(Num3i**2):
        Num3 = (1-numpy.sign(Num3r))*numpy.pi/2
    else:       
        Num3 = numpy.angle(Num3r+1j*Num3i)
    #Num3 = Num3 - 2*numpy.pi*round(numpy.mean(Num3)/(2*numpy.pi))
    
    Den1 = numpy.interp(psibar_Theta,psi,omega*s_Ray,period=2*numpy.pi)
    Den2 = numpy.interp(Theta,psi,cos_beta,period = 2*numpy.pi)
    #phi_0 = 120.91
    R = (phi_0 +Num1 + Num2 +Num3)/(Den1 * Den2)
    if plot:
        Thetaplot = numpy.linspace(Theta[0],Theta[-1],num=5000)
        if l==0:
            Rplot =  numpy.interp(Thetaplot,Theta,R)
        else:
            Rplot =  numpy.interp(Thetaplot,Theta[::-1],R[::-1])
            Den1Den2plot =  numpy.interp(Thetaplot,Theta[::-1],(Den1*Den2)[::-1])
            phi_0Num1Num2plot =  numpy.interp(Thetaplot,Theta[::-1],(phi_0+Num1+Num2+Theta)[::-1])
            Num3plot =  numpy.interp(Thetaplot,Theta[::-1],(Num3)[::-1])
            betaplot = numpy.interp(Thetaplot,Theta[::-1],(psibar_Theta-Theta)[::-1])
        #ax = plt.subplot(111, projection='polar')
        ax = plt.subplot(221)
        ax.plot(Thetaplot.tolist(), (Den1Den2plot).tolist(), color='r', linewidth=3)
        ax = plt.subplot(222)
        ax.plot(Thetaplot.tolist(), (betaplot).tolist(), color='r', linewidth=3)
        ax = plt.subplot(223)
        ax.plot(Thetaplot.tolist(), (Num3plot).tolist(), color='r', linewidth=3)
        ax = plt.subplot(224)
        ax.plot(Thetaplot.tolist(), (phi_0Num1Num2plot).tolist(), color='r', linewidth=3)
        #ax.set_rmax(max(Rplot))
        ax.grid(True)
        ax.set_title("R", va='bottom')
        plt.show(block = False)
        
    if save:
        sio.savemat('OutputR',{'R':R,'Theta':Theta,'phi_0':phi_0,'Num1':Num1,'Num2':Num2,'Num3':Num3,'Den1':Den1,'Den2':Den2})
        
    return R

def arctan2_02pi(y,x):
    theta1 = numpy.arctan2(y,x) #result between -pi and pi
    theta = theta1%(2*numpy.pi)
    return theta

def canonical_coords(lattitude,longitude):
    #returns spherical coordinates within [0,pi]x[0,2*pi]
    lattitude_can = numpy.arccos(numpy.cos(lattitude))
    longitude_can = arctan2_02pi(numpy.sin(longitude)*numpy.sin(lattitude), 
                             numpy.cos(longitude)*numpy.sin(lattitude))
    return lattitude_can,longitude_can

def gradient_h(sigma,psi,hder_sigma, hder_psi):
    return numpy.array([hder_sigma.evaluate(numpy.real(sigma),numpy.real(psi)),
                        hder_psi.evaluate(numpy.real(sigma),numpy.real(psi))])
    

def sphere2cart(lattitude,longitude,radius):
    x = radius*numpy.sin(lattitude)*numpy.cos(longitude)
    y = radius*numpy.sin(lattitude)*numpy.sin(longitude)
    z = radius*numpy.cos(lattitude)
    return x,y,z

def cart2sphere_02pi(x,y,z):
    radius = numpy.sqrt(x**2+y**2+z**2)
    lattitude = numpy.arccos(z/radius)
    longitude = arctan2_02pi(y,x)
    return lattitude,longitude,radius

def rotation_matrix(delta_lattitude,delta_longitude):
    #first Euler angle around z
    c, s = numpy.cos(delta_longitude), numpy.sin(delta_longitude)
    Rlongitude = numpy.matrix('{} {} {}; {} {} {};{} {} {}'.format(c, -s, 0, s, c, 0, 0, 0, 1))
    c, s = numpy.cos(delta_lattitude), numpy.sin(delta_lattitude)
    Rlattitude_y = numpy.matrix('{} {} {}; {} {} {};{} {} {}'.format(c, 0, -s, 0, 1, 0, s, 0, c))
    Rdirect = numpy.matmul(Rlongitude,Rlattitude_y)
    Rinverse = numpy.linalg.inv(Rdirect)
    return Rdirect,Rinverse

def beam_stirring_3D(psi,sigma,Theta,Phi,mu0,s_Ray,l,z0,Zn,filename = None):
    #computes sigmabar,psibar, h, hddot, hpprime, hdotprime
    plot = False
    if filename is None:
       save = False 
    else:
       save = True
       print('the file: ' + filename + ' does not exist yet, computing beam stirring...')
    #filename = 'beam_stirring_3D_results.p'
    show_error = True
    psibar = numpy.zeros_like(Theta)
    sigmabar = numpy.zeros_like(Theta)
    hpprime = numpy.zeros_like(Theta)
    hdotprime = numpy.zeros_like(Theta)
    hddot = numpy.zeros_like(Theta)
    htemp = numpy.zeros_like(Theta)
    bar = Bar('computing psibar,sigmabar', max=Theta.shape[0])
    for i in range(Phi.shape[0]):
        for j in range(Theta.shape[1]):
            print('[i,j]: '+str([i,j]))
            theta = Theta[i,j]
            phi = Phi[i,j]
            #in order to find a solution, s_Ray is projected on a spherical manifold
            #s_Ray_c = sphd.AngSpectrum(s_Ray,lattitude = sigma[:,0],longitude = psi[0,:],Nmax=6) #THE GRID MUST BE REGULAR!!!! cols are for the lattitude (0 to pi, lines for the longitude)
            h = s_Ray*(numpy.cos(psi-theta)*numpy.sin(phi)*numpy.sin(sigma)+numpy.cos(phi)*numpy.cos(sigma)*(-z0)/Zn) + mu0*numpy.cos(phi)
            #spherical interpolation
            h_c = sphd.AngSpectrum(h,lattitude = sigma[:,0],longitude = psi[0,:],Nmax=6)
            if False:
                print('theta = '+str(theta),'phi = '+str(phi))
                print('direct plot')
                h_c.plot_direct
                print('map h')
                plt.imshow(h)
                plt.show()
                print('spectrum')
                h_c.plot_reciprocal
                spherepy.pretty_coefs(h_c)
            hder_sigma = h_c.der_theta()
            hder_psi = h_c.der_phi()
            #solution
            print('preparing optimisation')
            F = lambda x: -1e3*h_c.evaluate(x[0],x[1]) #x[0]=sigmabar, x[1]=psibar
            #print('phi,theta = '+str([phi,theta]))
            #print('F(theta,phi)='+str(F(numpy.array([theta,phi]))))
            try:
                res = minimize(F,numpy.array([phi,theta]),bounds = [(0,numpy.pi),(0,2*numpy.pi)],tol = 1e-4)#line_search='armijo',alpha = float(-1/J)
                x = res.x #to be modified to include no convergence
            except NoConvergence:
                print('No convergence here')
                x = numpy.array([phi,theta])
                if show_error:
                    pass
                    #plot goes here
            #x0can,x1can = canonical_coords(x[0],x[1])
            print('optim terminated')
            x = numpy.real(x)
            dx0,dx1 = canonical_coords(x[0]-phi,x[1] - theta)
            dx = numpy.array([dx0,dx1])
            if numpy.any(numpy.absolute(dx)>0.3)&show_error:
                print('x='+str(x))
                print('dx='+str(dx))
                print('F(x)='+str(F(x)))
                print('F(phi,theta)='+str(F(numpy.array([phi,theta]))))
            sigmabar[i,j],psibar[i,j]= canonical_coords(x[0],x[1])
            hpprime[i,j]=numpy.real(hder_sigma.der_theta().evaluate(x[0],x[1]))
            hddot[i,j]=numpy.real(hder_psi.der_phi().evaluate(x[0],x[1]))
            hdotprime[i,j]=numpy.real(hder_sigma.der_theta().evaluate(x[0],x[1]))
            htemp[i,j] = numpy.real(h_c.evaluate(x[0],x[1]))
            
        #print('computing psibar,sigmabar: ' + str(100*i/Theta.shape[0]) + '%')
        bar.next()
    bar.finish()
    if plot:    
        plt.hist((psibar-Theta).tolist(), 50)
        plt.show(block = False)
        plt.hist((sigmabar-Phi).tolist(), 50)
        plt.show(block = False)
        dpsibar_pp = RectSphereBivariateSpline(Phi[:,0]+1e-6, Theta[0,:]+1e-6, (psibar - Theta))
        dsigmabar_pp = RectSphereBivariateSpline(Phi[:,0]+1e-6, Theta[0,:]+1e-6, (sigmabar - Phi)) #%numpy.pi
        plot_on_sphere(Phi[:,0]+1e-6,Theta[0,:]+1e-6,numpy.ones_like(Theta),dpsibar_pp.__call__(Phi[:,0],Theta[0,:]))
        plot_on_sphere(Phi[:,0]+1e-6,Theta[0,:]+1e-6,numpy.ones_like(Theta),dsigmabar_pp.__call__(Phi[:,0],Theta[0,:]))
        plot_on_sphere(Phi[:,0]+1e-6,Theta[0,:]+1e-6,numpy.ones_like(Theta),hdotprime)

    if save:
            with open(filename, 'wb') as fp:
                print('saving')
                pickle.dump({'sigmabar':sigmabar,'psibar':psibar, 'h':htemp, 'hddot':hddot, 'hpprime':hpprime, 'hdotprime':hdotprime}, fp)
                print('done')

    return sigmabar,psibar, htemp, hddot, hpprime, hdotprime


def beam_stirring_3D_old(psi,sigma,Theta,Phi,mu0,s_Ray,l,z0,Zn,filename = None):
    #computes sigmabar,psibar, h, hddot, hpprime, hdotprime
    plot = False
    if filename is None:
       save = False 
    else:
       save = True
       print('the file: ' + filename + ' does not exist yet, computing beam stirring...')
    #filename = 'beam_stirring_3D_results.p'
    show_error = True
    psibar = numpy.zeros_like(Theta)
    sigmabar = numpy.zeros_like(Theta)
    hpprime = numpy.zeros_like(Theta)
    hdotprime = numpy.zeros_like(Theta)
    hddot = numpy.zeros_like(Theta)
    htemp = numpy.zeros_like(Theta)
    bar = Bar('computing psibar,sigmabar', max=Theta.shape[0])
    for i in range(Phi.shape[0]):
        for j in range(Theta.shape[1]):
            print('[i,j]: '+str([i,j]))
            theta = Theta[i,j]
            phi = Phi[i,j]
            #in order to find a solution, s_Ray is projected on a spherical manifold
            #s_Ray_c = sphd.AngSpectrum(s_Ray,lattitude = sigma[:,0],longitude = psi[0,:],Nmax=6) #THE GRID MUST BE REGULAR!!!! cols are for the lattitude (0 to pi, lines for the longitude)
            h = s_Ray*(numpy.cos(psi-theta)*numpy.sin(phi)*numpy.sin(sigma)+numpy.cos(phi)*numpy.cos(sigma)*(-z0)/Zn)# + mu0*numpy.cos(phi)
            #spherical interpolation
            h_c = sphd.AngSpectrum(h,lattitude = sigma[:,0],longitude = psi[0,:],Nmax=6)
            if i==2:
                print('theta = '+str(theta),'phi = '+str(phi))
                print('direct plot')
                h_c.plot_direct
                print('map h')
                plt.imshow(h)
                plt.show()
                print('spectrum')
                h_c.plot_reciprocal
                spherepy.pretty_coefs(h_c)
            #solution
            hder_sigma = h_c.der_theta()
            hder_psi = h_c.der_phi()
            if i==2:
                print('direct plot hder_sigma')
                hder_sigma.plot_direct
                print('map hder_sigma')
                plt.imshow(numpy.real(hder_sigma.evaluate(sigma,psi)))
                plt.colorbar()
                plt.show()
                print('spectrum hder_sigma')
                hder_sigma.plot_reciprocal
                spherepy.pretty_coefs(hder_sigma)
                print('direct plot hder_psi')
                hder_psi.plot_direct
                print('spectrum hder_psi')
                hder_psi.plot_reciprocal
            print('preparing optimisation')
            F = lambda x: 1e3*gradient_h(x[0],x[1],hder_sigma,hder_psi) #x[0]=sigmabar, x[1]=psibar
            #print('phi,theta = '+str([phi,theta]))
            #print('F(theta,phi)='+str(F(numpy.array([theta,phi]))))
            try:
                x = excitingmixing(F,numpy.array([phi,theta]),line_search='armijo',maxiter = int(1e4),f_tol = 1e-4,verbose=False)#line_search='armijo',alpha = float(-1/J)
            except NoConvergence:
                print('No convergence here')
                x = numpy.array([phi,theta])
                if show_error:
                    pass
                    #plot goes here
            #x0can,x1can = canonical_coords(x[0],x[1])
            print('optim terminated')
            x = numpy.real(x)
            dx0,dx1 = canonical_coords(x[0]-phi,x[1] - theta)
            dx = numpy.array([dx0,dx1])
            if numpy.any(numpy.absolute(dx)>0.3)&show_error:
                print('x='+str(x))
                print('dx='+str(dx))
                print('F(x)='+str(F(x)))
                print('F(phi,theta)='+str(F(numpy.array([phi,theta]))))
            sigmabar[i,j],psibar[i,j]= canonical_coords(x[0],x[1])
            hpprime[i,j]=numpy.real(hder_sigma.der_theta().evaluate(x[0],x[1]))
            hddot[i,j]=numpy.real(hder_psi.der_phi().evaluate(x[0],x[1]))
            hdotprime[i,j]=numpy.real(hder_sigma.der_theta().evaluate(x[0],x[1]))
            htemp[i,j] = numpy.real(h_c.evaluate(x[0],x[1]))
            
        #print('computing psibar,sigmabar: ' + str(100*i/Theta.shape[0]) + '%')
        bar.next()
    bar.finish()
    if plot:    
        plt.hist((psibar-Theta).tolist(), 50)
        plt.show(block = False)
        plt.hist((sigmabar-Phi).tolist(), 50)
        plt.show(block = False)
        dpsibar_pp = RectSphereBivariateSpline(Phi[:,0]+1e-6, Theta[0,:]+1e-6, (psibar - Theta))
        dsigmabar_pp = RectSphereBivariateSpline(Phi[:,0]+1e-6, Theta[0,:]+1e-6, (sigmabar - Phi)) #%numpy.pi
        plot_on_sphere(Phi[:,0]+1e-6,Theta[0,:]+1e-6,numpy.ones_like(Theta),dpsibar_pp.__call__(Phi[:,0],Theta[0,:]))
        plot_on_sphere(Phi[:,0]+1e-6,Theta[0,:]+1e-6,numpy.ones_like(Theta),dsigmabar_pp.__call__(Phi[:,0],Theta[0,:]))
        plot_on_sphere(Phi[:,0]+1e-6,Theta[0,:]+1e-6,numpy.ones_like(Theta),hdotprime)

    if save:
            with open(filename, 'wb') as fp:
                print('saving')
                pickle.dump({'sigmabar':sigmabar,'psibar':psibar, 'h':htemp, 'hddot':hddot, 'hpprime':hpprime, 'hdotprime':hdotprime}, fp)
                print('done')

    return sigmabar,psibar, htemp, hddot, hpprime, hdotprime

def isophase_function(r,theta,l,a_c,h_c,omega,Zn,Theta0,dsigmabar_c,dpsibar_c, output = 'phase'):
    phi = numpy.pi/2 - numpy.arctan2(-Zn,r)
    phican,thetacan = canonical_coords(phi,theta)
    rho = numpy.sqrt(r**2+Zn**2)
    sigmabar = phican+numpy.real(dsigmabar_c.evaluate(phican,thetacan))
    psibar = thetacan+numpy.real(dpsibar_c.evaluate(phican,thetacan))
    sigmabarcan,psibarcan = canonical_coords(sigmabar,psibar)
    alpha_bar = 0#numpy.angle(a_c.evaluate(sigmabarcan,psibarcan))#%(2*numpy.pi)
    h_bar = numpy.real(h_c.evaluate(phican,thetacan))
    #y0 = r*numpy.tan(phican)-z0
    y =  numpy.real(-l*theta - alpha_bar + h_bar*omega*rho - Theta0)
    mu_0_bar = None #for compatibility
    all_output = {'mu_0_bar':mu_0_bar,'ltheta':l*theta, 'alpha_bar': alpha_bar, 'hbar':h_bar,'Zn':Zn,'Theta0':Theta0,'phase':y}
    if output=='all':
        return all_output
    else:
        return numpy.array([all_output[output]]) #numpy.array([y])


def isotropic_solution(theta,mu_0avg,a_avg,l,s_ray_avg,omega,Zn,Theta0):
    #phican,thetacan = canonical_coords(phi,theta)
    #rho = numpy.sqrt(r^2+z^2)
    #sigmabar = phican
    #psibar = thetacan
    mu_0_bar = mu_0avg
    alpha_bar = numpy.angle(a_avg)
    r = numpy.sqrt(
        ((Theta0 + l*theta + alpha_bar)/(s_ray_avg*omega))**2 -Zn**2)
    x0 = r
    x1 = arctan2_02pi(Zn,r) 
    return r #numpy.array([x0,x1])

def remove_nan(x,y):
    #removes nan values from a 1D dataset by interpolation
    #https://docs.scipy.org/doc/scipy/reference/generated/scipy.interpolate.UnivariateSpline.html
    w = numpy.isnan(y)
    y[w] = 0.
    try:
        spl = UnivariateSpline(x, y, w=~w,s=0) #If s=0, spline will interpolate through all data points.
        return spl(x)
    except ValueError: #x must be strictly increasing
        x = x[::-1]
        y = y[::-1]
        w = w[::-1]
        spl = UnivariateSpline(x, y, w=~w,s=0)
        return spl(x[::-1])
    

def IDT_Master_Curve_3D(psi,sigma,Theta,Phi,mu_0,s_Ray,l,omega,Theta0,a,z,z0,ThetaMesh,sigmabar_psibar_filename=None,isotropic = False): #TO_CHECK
    plot = False
    plot_stirring = False
    PlotNoConvergence = True
    check_convergence = False
    saveMatlab = False
    #filename = 'beam_stirring_3D_results.p'
    show_error = False
    R = []
    R_iso = []
    jumps = 0
    max_jumps = 3
    Zn = max(z)-z0
    if sigmabar_psibar_filename is None:
        print('computing beam stirring...')
        sigmabar,psibar, h, hddot, hpprime, hdotprime = beam_stirring_3D(psi,sigma,Theta,Phi,mu_0,s_Ray,l,z0,Zn)
        print('done.')
    else:
        try:
            with open(sigmabar_psibar_filename, 'rb') as fp:
               hvars = pickle.load(fp)
               sigmabar = hvars['sigmabar']
               psibar = hvars['psibar']
               h = hvars['h']
               hddot = hvars['hddot']
               hpprime = hvars['hpprime']
               hdotprime = hvars['hdotprime']
        except IOError: #the file does not exist yet
            sigmabar,psibar, h, hddot, hpprime, hdotprime = beam_stirring_3D(psi,sigma,Theta,Phi,mu_0,s_Ray,l,z0,Zn,filename = sigmabar_psibar_filename)
                
    if plot_stirring:
        plt.hist(numpy.sin(psibar-Theta).tolist(), 50)
        plt.show()
        plt.hist(numpy.sin(sigmabar-Phi).tolist(), 50)
        plt.show()
        #dpsibar_pp = RectSphereBivariateSpline(Phi[:,0]+1e-6, Theta[0,:]+1e-6, numpy.sin(psibar - Theta))
        #dsigmabar_pp = RectSphereBivariateSpline(Phi[:,0]+1e-6, Theta[0,:]+1e-6, numpy.sin(sigmabar - Phi)) #%numpy.pi
        #plot_on_sphere(Phi[:,0]+1e-6,Theta[0,:]+1e-6,numpy.ones_like(Theta),dpsibar_pp.__call__(Phi[:,0],Theta[0,:]))
        #plot_on_sphere(Phi[:,0]+1e-6,Theta[0,:]+1e-6,numpy.ones_like(Theta),dsigmabar_pp.__call__(Phi[:,0],Theta[0,:]))
        #plot_on_sphere(Phi[:,0]+1e-6,Theta[0,:]+1e-6,numpy.ones_like(Theta),hdotprime)

    #dsigmabar_pp = RectSphereBivariateSpline(Phi[:,0]+1e-6, Theta[0,:]+1e-6,sigmabar-Phi)
    dsigmabar_c = sphd.AngSpectrum(sigmabar-Phi,lattitude = Phi[:,0], longitude = Theta[0,:],Nmax = 6)
    #dpsibar_pp = RectSphereBivariateSpline(Phi[:,0]+1e-6, Theta[0,:]+1e-6,psibar-Theta)
    dpsibar_c = sphd.AngSpectrum(psibar-Theta,lattitude = Phi[:,0], longitude = Theta[0,:],Nmax = 6)
    #mu_0pp = RectSphereBivariateSpline(sigma[:,0]+1e-6, psi[0,:]+1e-6,mu_0)
    mu_0c = sphd.AngSpectrum(mu_0,lattitude = sigma[:,0], longitude = psi[0,:],Nmax = 6)   
    #a_pp = RectSphereBivariateSpline(sigma[:,0]+1e-6, psi[0,:]+1e-6,a)
    a_c = sphd.AngSpectrum(a, lattitude = sigma[:,0], longitude = psi[0,:],Nmax = 6)
    #h_pp = RectSphereBivariateSpline(Phi[:,0]+1e-6, Theta[0,:]+1e-6,h)
    h_c = sphd.AngSpectrum(h, lattitude = Phi[:,0], longitude = Theta[0,:],Nmax = 6)
    mu_0avg = numpy.mean(mu_0.ravel())
    a_avg = numpy.mean(a.ravel())
    s_Ray_avg = numpy.mean(s_Ray.ravel())
    if plot_stirring:
        h_c.plot_direct; mu_0c.plot_direct; a_c.plot_direct;
    
    previous_solution = isotropic_solution(ThetaMesh[0],mu_0avg,a_avg,l,s_Ray_avg,omega,Zn,Theta0)
    drdtheta = 0. #Taylor approximation of the first guess to accelerate the convergence
    theta_previous = ThetaMesh[0]
    dtheta = 0.
    dtheta_max = 0.
    initial_guess = previous_solution + drdtheta*dtheta #1st order Taylor
    first_order_error = 0.
    x = previous_solution
    bar = Bar('computing master curve', max=len(ThetaMesh)/20)
    for theta in ThetaMesh:
        #print('theta = '+str(theta))
        if isotropic:
            isotropic_estimate = isotropic_solution(theta,mu_0avg,a_avg,l,s_Ray_avg,omega,Zn,Theta0)
            x = isotropic_estimate
        else: #numerical solution
            x,dtheta_max,theta_previous,previous_solution,drdtheta,dtheta,isotropic_estimate = solve_R(theta,dtheta_max,
            theta_previous,previous_solution,drdtheta,s_Ray_avg,dtheta,l,a_c,h_c,omega,Zn,
            Theta0,dsigmabar_c,dpsibar_c,mu_0avg,a_avg,check_convergence,PlotNoConvergence,jumps,max_jumps,ThetaMesh)
        R.append(float(x))
        R_iso.append(isotropic_estimate)
        if len(R)%20==0:
            #print('computing master curve: ' + str(100.*len(R)/len(ThetaMesh)) + '%')
            bar.next()
    bar.finish()
    if plot:
        R2 = numpy.array(R)
        fraction_NaN = max(R2[R2!=R2].shape)*1.0/len(ThetaMesh)
        print('fraction_NaN: ' + str(100*fraction_NaN) + '%')
        ax = plt.subplot(111, projection='polar')
        ax.plot(ThetaMesh,R)
        plt.show()#block = False)
        ax = plt.subplot(111)
        ax.plot(range(len(ThetaMesh)),numpy.array(R_iso)-numpy.array(R))
        plt.show()#block = False)
        
    if saveMatlab:
        sio.savemat('OutputR',{'R':R,'Theta':ThetaMesh})

    R = remove_nan(numpy.array(ThetaMesh),numpy.array(R))
    return R

def solve_R(theta,dtheta_max,theta_previous,previous_solution,drdtheta,s_Ray_avg,dtheta,l,a_c,h_c,omega,Zn,
            Theta0,dsigmabar_c,dpsibar_c,mu_0avg,a_avg,check_convergence,PlotNoConvergence,jumps,max_jumps,ThetaMesh):
    #looking for the optimal step
    #previous solution is the actually computed previous solution
    #x is the previous output, which may have been linearly interpolated
    dtheta_now = numpy.fmod(theta - theta_previous,2*numpy.pi)
    initial_guess = previous_solution + drdtheta*dtheta_now #1st order Taylor
    isotropic_estimate = isotropic_solution(theta,mu_0avg,a_avg,l,s_Ray_avg,omega,Zn,Theta0)
    if abs(dtheta_now) >= dtheta_max:
        dtheta = dtheta_now
        F = lambda r: isophase_function(r,theta,l,a_c,h_c,omega,Zn,Theta0,dsigmabar_c,dpsibar_c)
        Fplot = lambda r: isophase_function(r,theta,l,a_c,h_c,omega,Zn,Theta0,dsigmabar_c,dpsibar_c,output = 'phase')
        try:  #broyden1,broyden2,excitingmixing
            x = broyden1(F,initial_guess,line_search='armijo',maxiter = int(1e3),f_tol = 2*numpy.pi*1e-4) #tolerance of 1/1000th on the phase
            #print('x-prev_solution = '+str(abs(x-previous_solution)))
            #print('x-initial_guess = '+str(abs(x-initial_guess)))
        except NoConvergence:
            print('convergence failed. previous_solution = '+str(previous_solution))
            print('isotropic solution = ' + str(isotropic_solution(theta,mu_0avg,a_avg,l,s_Ray_avg,omega,Zn,Theta0)))
            print('trying again with verbose')
            try:
                x = broyden1(F,initial_guess,line_search='armijo',maxiter = int(1e3),verbose = True)
                if dtheta == 0:
                    drdtheta = 0
                else:
                    drdtheta = (x - previous_solution)/dtheta
                previous_solution = x
                theta_previous = theta
            except NoConvergence: #failed again as expected
                if PlotNoConvergence:
                    print(isophase_function(10e-6,theta,l,a_c,h_c,omega,Zn,Theta0,dsigmabar_c,dpsibar_c,output = 'all'))
                    X = numpy.arange(10e-6,10e-3,10e-6)
                    FX = []
                    for x in X:
                        FX.append(Fplot(x))
                    plt.plot(X, FX)
                    print(previous_solution)
                    plt.show(block = True)
                else:
                    x = numpy.nan#isotropic_estimate
                raise NoConvergence
            raise NoConvergence
        #convergence successful
        max_error_allowed = 2*numpy.pi/(omega*10*s_Ray_avg)
        if numpy.abs(x-previous_solution) < max_error_allowed or not check_convergence: #difference below lambda/4
            if dtheta == 0:
                drdtheta = 0
            else:
                drdtheta = (x - previous_solution)/dtheta
            first_order_error = x-initial_guess
            previous_solution = x
            theta_previous = theta
            dtheta_max = min(numpy.pi/20,numpy.sqrt(0.5*max_error_allowed*dtheta**2/first_order_error)) #0.5 safety coef.
        else: #it seems there was a step
            print('convergence error: ' + str(100*numpy.abs(x-previous_solution)/(2*numpy.pi/(omega*10*s_Ray_avg))) + '%')
            print('x = ' + str(x) + 'mm , x_previous = ' + str(previous_solution))
            if theta == ThetaMesh[0]: #it's okay, the first estimate was possibly wrong
                previous_solution = x
            elif PlotNoConvergence:
                jumps+=1
                if jumps>max_jumps:
                    raise NoConvergence
                X = numpy.arange(10e-6,10e-3,10e-6)
                FX = []
                for x in X:
                    FX.append(Fplot(x))
                plt.plot(X, FX)
                plt.show(block = True)
    else:
       x = initial_guess
    return x,dtheta_max,theta_previous,previous_solution,drdtheta,dtheta,isotropic_estimate


def Electrode_pattern(electrode_type,phi_0):
    return{
    'IDT': 
        [phi_0+2.*numpy.pi*numpy.array([0]),phi_0+2.*numpy.pi*numpy.array([0.5])],
    'snail': 
        [phi_0+2.*numpy.pi*numpy.array([0]),phi_0+2.*numpy.pi*numpy.array([0.5])],
    'snail_2': 
        [phi_0+2.*numpy.pi*numpy.array([0]),phi_0+2.*numpy.pi*numpy.array([0.5])],
    'splitIDT': 
        [phi_0+2.*numpy.pi*numpy.array([0,0.25]),phi_0+2.*numpy.pi*numpy.array([0.5,0.75])],
    }[electrode_type]

def MasterCurve2Electrodes_3D(electrode_type,Theta0,psi,sigma,Theta,Phi,mu0,s_Ray,l,omega,a,z,z0,ThetaMesh,sigmabar_psibar_FileName = None, isotropy = False):
    plot = False
    Theta0 = Electrode_pattern(electrode_type,Theta0)
    Rlist = [[],[]]
    Rwidth = [[],[]]
    Thetalist = [[],[]]
    for polarity in range(2):
        for i in range(len(Theta0[polarity])):
            if electrode_type in ['snail']:
                ThetaMesh_temp = (numpy.array(ThetaMesh)-l*polarity*numpy.pi).tolist()
            else:
                ThetaMesh_temp = ThetaMesh
            if l==0:
                n_turns = len(ThetaMesh)
                for n in range(n_turns):
                    R = IDT_Master_Curve_3D(psi,sigma,Theta,Phi,mu0,s_Ray,l,omega,Theta0[polarity][i]+n*2*numpy.pi,a,z,z0,ThetaMesh[n]
                                            ,sigmabar_psibar_filename = sigmabar_psibar_FileName)
                    Rw = IDT_Master_Curve_3D(psi,sigma,Theta,Phi,mu0,s_Ray,l,omega,Theta0[polarity][i]+n*2*numpy.pi+numpy.pi/2,a,z,z0,ThetaMesh[n]
                                            ,sigmabar_psibar_filename = sigmabar_psibar_FileName)
                    Rlist[polarity].append(R)
                    Thetalist[polarity].append(ThetaMesh[n])
                    Rwidth[polarity].append(Rw) 
            else:
                if l<0:
                    for n in range(abs(l)):
                            R = IDT_Master_Curve_3D(psi,sigma,Theta,Phi,mu0,s_Ray,l,omega,Theta0[polarity][i]-n*2*numpy.pi,a,z,z0,ThetaMesh_temp
                                                    ,sigmabar_psibar_filename = sigmabar_psibar_FileName,isotropic = isotropy)
                            Rw = IDT_Master_Curve_3D(psi,sigma,Theta,Phi,mu0,s_Ray,l,omega,Theta0[polarity][i]-n*2*numpy.pi+numpy.pi/2,a,z,z0,ThetaMesh_temp
                                                    ,sigmabar_psibar_filename = sigmabar_psibar_FileName,isotropic = isotropy)
                            Rlist[polarity].append(R) 
                            Thetalist[polarity].append(ThetaMesh_temp)
                            Rwidth[polarity].append(Rw) 
                else:
                    for n in range(l):
                            R = IDT_Master_Curve_3D(psi,sigma,Theta,Phi,mu0,s_Ray,l,omega,Theta0[polarity][i]+n*2*numpy.pi,a,z,z0,ThetaMesh_temp
                                                    ,sigmabar_psibar_filename = sigmabar_psibar_FileName,isotropic = isotropy)
                            Rw = IDT_Master_Curve_3D(psi,sigma,Theta,Phi,mu0,s_Ray,l,omega,Theta0[polarity][i]+n*2*numpy.pi+numpy.pi/2,a,z,z0,ThetaMesh_temp
                                                    ,sigmabar_psibar_filename = sigmabar_psibar_FileName,isotropic = isotropy)
                            Rlist[polarity].append(R) 
                            Thetalist[polarity].append(ThetaMesh_temp)
                            Rwidth[polarity].append(Rw) 

    if plot:
        ax = plt.subplot(111, projection='polar')
        for polarity in range(2):
            for i in range(len(Theta0[polarity])):
                ax.plot(Thetalist[polarity][i],Rlist[polarity][i])
        ax.set_title('MasterCurve2Electrodes_3D_output')        
        plt.show()#block = False)

    IDT_data = {'R':Rlist,'Theta':Thetalist,'Rwidth':Rwidth} #'IDT': IDT, 
    return IDT_data





def MasterCurve2Electrodes(electrode_type,phi_0,psi,Theta,mu_0,s_Ray,l,omega,a,lambda_approx):
    #plot = False    
    Phi_0 = Electrode_pattern(electrode_type,phi_0)
    Rlist = [[],[]]
    Thetalist = [[],[]]
    for polarity in range(2):
        for i in range(len(Phi_0[polarity])):
            if l==0:
                n_turns = len(Theta)
                for n in range(n_turns):
                    R = IDT_Master_Curve(psi,Theta[n],mu_0,s_Ray,0,omega,Phi_0[polarity][i]+n*2*numpy.pi,a)                     
                    Rlist[polarity].append(R) 
                    Thetalist[polarity].append(Theta[n]) 
            else:
                if l<0:
                    for n in range(abs(l)):
                        if electrode_type in ['snail']:
                            Theta_temp = (numpy.array(Theta)-l*polarity*numpy.pi).tolist()
                            R = IDT_Master_Curve(psi,Theta_temp,mu_0,s_Ray,l,omega,Phi_0[polarity][i]-n*2*numpy.pi,a)
                            Rlist[polarity].append(R) 
                            Thetalist[polarity].append(Theta_temp) 
                        else:
                            R = IDT_Master_Curve(psi,Theta,mu_0,s_Ray,l,omega,Phi_0[polarity][i]-n*2*numpy.pi,a)
                            Rlist[polarity].append(R) 
                            Thetalist[polarity].append(Theta) 
                else:
                    for n in range(l):
                        if electrode_type in ['snail']:
                            Theta_temp = (numpy.array(Theta)-l*polarity*numpy.pi).tolist()
                            R = IDT_Master_Curve(psi,Theta_temp,mu_0,s_Ray,l,omega,Phi_0[polarity][i]+n*2*numpy.pi,a)
                            Rlist[polarity].append(R) 
                            Thetalist[polarity].append(Theta_temp) 
                        else:
                            R = IDT_Master_Curve(psi,Theta,mu_0,s_Ray,l,omega,Phi_0[polarity][i]-n*2*numpy.pi,a)
                            Rlist[polarity].append(R) 
                            Thetalist[polarity].append(Theta) 
    
    IDT_data = {'R':Rlist,'Theta':Thetalist} #'IDT': IDT, 
    return IDT_data



        
def Place_Electrodes(l,phi_0,lambda_approx,electrodes_angle,electrodes_thickness,removal_thickness,IDT_data,electrode_type,electrode_rotate_angle=0):
    plot = False
    Rlist = IDT_data['R']
    Thetalist = IDT_data['Theta']
    Rline = [[],[]]
    xyelect = [[],[]]
    Rmin_abs = []
    if l<0:
        electrode_rotate_angle = electrode_rotate_angle+180
    for polarity in range(len(Rlist)):
        if (electrode_type in ['snail','snail_2']) or (polarity==0):
            Rmin = []
            Rmax = []
        for i in range(len(Rlist[polarity])):
            R = Rlist[polarity][i]
            Theta = Thetalist[polarity][i]
            if electrode_type in ['snail','snail_2']:
                Rmin = min([min([R[-1],R[0]]),Rmin]) #on the ends
                Rmax = max([max([R[-1],R[0]]),Rmax])
            else:
                Rmin = min([R.min(),Rmin])
                Rmax = max([R.max(),Rmax])
            xy = pol2cart(Theta,R)
            if l==0:
                #Rline[polarity].append(shapely_geom.LinearRing(shapely_geom.asLineString(xy)))
                Rline[polarity].append(shapely_geom.LinearRing(xy))
            else:
                Rline[polarity].append(shapely_geom.LineString(xy))
        if electrode_type in ['snail','snail_2']:#possibly other shapes
            Rmax = 1.5*Rmax
            Rmin = Rmin - lambda_approx/10
            xyelect[polarity] = pol2cart([electrodes_angle[polarity],electrodes_angle[polarity]],[Rmax/1.5,Rmax])
            #xyelect1 = pol2cart([electrodes_angle[1],electrodes_angle[1]],[Rmax/1.5,Rmax])
        else:
            if polarity==0:
                Rmax = 1.5*Rmax
                Rmin = 0.95*Rmin
            xyelect[polarity] = pol2cart([electrodes_angle[polarity],electrodes_angle[polarity]],[Rmin,Rmax])
            #xyelect1 = pol2cart([electrodes_angle[1],electrodes_angle[1]],[Rmin,Rmax])
        Rmin_abs = min([Rmin,Rmin_abs])
    xyelect0 = xyelect[0]
    xyelect1 = xyelect[1]
    elect0 = shapely_geom.LineString([(xyelect0[0,0],xyelect0[0,1]),(xyelect0[1,0],xyelect0[1,1])])
    elect1 = shapely_geom.LineString([(xyelect1[0,0],xyelect1[0,1]),(xyelect1[1,0],xyelect1[1,1])])
    elect0 = shapely_affinity.rotate(elect0, electrode_rotate_angle, origin=(xyelect0[0,0],xyelect0[0,1]), use_radians=False) 
    elect1 = shapely_affinity.rotate(elect1, electrode_rotate_angle, origin=(xyelect1[0,0],xyelect1[0,1]), use_radians=False)
    removal0 = deepcopy(elect0)
    removal1 = deepcopy(elect1)
    
    removal_center = shapely_geom.Point(0.,0.).buffer(Rmin_abs-electrodes_thickness*thickness_factor(electrode_type)/2)
    
    Elect0_polyg = elect0.buffer(electrodes_thickness/2) 
    Elect1_polyg = elect1.buffer(electrodes_thickness/2)
    
    IDT_data['removal'] = {'removal0':removal0.buffer(removal_thickness/2),
                            'removal1':removal1.buffer(removal_thickness/2),
                            'removal_center':removal_center}  
                            
    if False:#electrode_rotate_angle != 0. : #draw hollow electrode to avoid forcing opposite voltage to the wave
        Hole_elect0 = elect0.buffer(electrodes_thickness/4) #up to 50% of the power branch can be hollow
        Hole_elect1 = elect1.buffer(electrodes_thickness/4)
        Phi_0 = Electrode_pattern(electrode_type,phi_0)
        N = Phi_0[0].size+Phi_0[1].size #number of electrodes over lambda
        Hole_elect0 = Hole_elect0.intersection(shapely_geom.MultiLineString(Rline[1]).buffer(lambda_approx/(4*N)))
        Hole_elect1 = Hole_elect1.intersection(shapely_geom.MultiLineString(Rline[0]).buffer(lambda_approx/(4*N)))
        IDT_data['removal']['Hole_elect0'] = Hole_elect0
        IDT_data['removal']['Hole_elect1'] = Hole_elect1
        #Elect0_polyg  = Elect0_polyg.difference(Hole_elect0)  
        #Elect1_polyg  = Elect1_polyg.difference(Hole_elect1)
  

    print(len(Rline[0]))
    if electrode_type not in ['snail','snail_2']:     
        pass#Rline = clean_edges(Rline,elect0,elect1)
    print(len(Rline[0]))
    
    IDT_data['electrodes'] = {'elect0':Elect0_polyg,
                            'elect1':Elect1_polyg}                        
    IDT_data['Rline'] = Rline
    
    if plot:
        ax = plt.subplot(111)
        patch1 = PolygonPatch(elect0.buffer(electrodes_thickness/2), fc=RED, ec=RED, alpha=0.5, zorder=2)
        ax.add_patch(patch1)
        patch2 = PolygonPatch(elect1.buffer(electrodes_thickness/2), fc=BLUE, ec=BLUE, alpha=0.5, zorder=2)
        ax.add_patch(patch2)    
        ax.set_title('a) dilation, cap_style=3')
        xrange = [-0.005, +0.005]
        yrange = [-0.005, +0.005]
        ax.axis([xrange[0],xrange[1], yrange[0], yrange[1]])
        ax.set_aspect(1)
        plt.show(block = False)
    #return IDT_data



def clean_edges(Rlinelist,elect0,elect1):
    plot = False
    Electrodes = shapely_geom.MultiLineString([elect0,elect1])
    Rline_cleaned = [[],[]]
    for polarity in range(len(Rlinelist)):
        #Rline = shapely_geom.collection.GeometryCollection(Rlinelist[polarity])   
        for n in range(len(Rlinelist[polarity])):
            Rline =  Rlinelist[polarity][n]
            Rsegments = Rline.difference(Electrodes)
            check_linear_ring = Rsegments.geoms[0].coords[0]==Rsegments.geoms[-1].coords[-1]
            check_no_intersection = not shapely_geom.Point(Rsegments.geoms[0].coords[0]).buffer(1e-9).intersects(Electrodes)
            if check_linear_ring and check_no_intersection: #there seems to be a bug in the linear ring intersection of shapely
                Rsegments_geoms_0 = shapely_ops.linemerge([Rsegments.geoms[0],Rsegments.geoms[-1]])
                Rsegments_temp = [Rsegments_geoms_0]                
                for i in range(len(Rsegments.geoms)-2):
                    Rsegments_temp.append(Rsegments[i+1])
                Rsegments = shapely_geom.MultiLineString(Rsegments_temp)
            for segment in Rsegments.geoms:
                
                if plot:
                    ax = plt.subplot(111)
                    segmentarray = numpy.array(segment.coords)
                    elect0array = numpy.array(elect0.coords)
                    elect1array = numpy.array(elect1.coords)
                    ax.plot(segmentarray[:,0].tolist(), segmentarray[:,1].tolist(), color='k', linewidth=3)
                    ax.plot(elect0array[:,0].tolist(), elect0array[:,1].tolist(), color='b', linewidth=3)
                    ax.plot(elect1array[:,0].tolist(), elect1array[:,1].tolist(), color='r', linewidth=3)
                    ax.axis([min(segmentarray[:,0]),max(segmentarray[:,0]),min(segmentarray[:,1]), max(segmentarray[:,1])])   
                    ax.set_aspect(1)
                    ax.grid(True)
                    plt.show(block = False)
                
                if segment.buffer(1e-9).intersects(elect0) and segment.buffer(1e-9).intersects(elect1): #there seems to be a numerical issue with small segments
                    Rline_cleaned[polarity].append(segment)

    return Rline_cleaned


def Enlarge_IDT(IDT_data,phi_0,electrode_type,lambda_approx,simplify = True): 
    plot = False   
    #Rlist = IDT_data['R']
    #Thetalist = IDT_data['Theta']
    Rline_all = IDT_data['Rline']
    Phi_0 = Electrode_pattern(electrode_type,phi_0)
    N = Phi_0[0].size+Phi_0[1].size #number of electrodes over lambda
    IDT = [[],[]]
    for polarity in range(len(Rline_all)):
        #print(len(IDT_data['Rwidth'][polarity]))
        #print(len(IDT_data['R'][polarity]))
        #print(len(IDT_data['Rline'][polarity]))
        for i in range(len(Rline_all[polarity])):
            Rline = Rline_all[polarity][i]
            if 'Rwidth' in IDT_data:
                Rwidth = 0.5*(IDT_data['Rwidth'][polarity][i]-IDT_data['R'][polarity][i])
                print('using variable width')
            else:
                Rwidth = lambda_approx/(4*N)
                print('using constant width')
            #R = Rlist[polarity][i]
            #Theta = Thetalist[polarity][i]
            #xy = pol2cart(Theta,R)
            #Rline = shapely_geom.asLineString(xy)
            Rlinebuffer = Rline.buffer(Rwidth)
            if simplify:
                Rlinebuffer.simplify(lambda_approx/16, preserve_topology=False)
            IDT[polarity].append(Rlinebuffer) #for a coverage of 50%
    IDT_data['IDT']=IDT
    if plot:
        #fig = plt.figure(1, figsize=SIZE, dpi=90)
        ax = plt.subplot(111)
        for polygon in IDT[0]:
            patch1 = PolygonPatch(polygon, fc=RED, ec=RED, alpha=0.5, zorder=2)
            ax.add_patch(patch1)
        for polygon in IDT[1]:
            patch2 = PolygonPatch(polygon, fc=BLUE, ec=BLUE, alpha=0.5, zorder=2)
            ax.add_patch(patch2)    
        ax.set_title('a) dilation, cap_style=3')
        #xrange = [1.1*min(xy[:,0]), 1.1*max(xy[:,0])]
        #yrange = [1.1*min(xy[:,1]), 1.1*max(xy[:,1])]
        #ax.axis([xrange[0],xrange[1], yrange[0], yrange[1]])
        ax.set_aspect(1)
        plt.show(block = False)        

def Draw_IDT(IDT_data):
    IDT = IDT_data['IDT']
    ax = plt.subplot(111)
    branch0 = IDT_data['electrodes']['elect0']
    branch1 = IDT_data['electrodes']['elect1']
    removal0 = IDT_data['removal']['removal0']
    removal1 = IDT_data['removal']['removal1']
    reticule = IDT_data['reticule']
    removal_center = IDT_data['removal']['removal_center']
    for polygon in IDT[0]:
        branch0 = branch0.union(polygon)       
    branch0 = branch0.difference(removal1)
    if 'Hole_elect0' in IDT_data['removal'].keys():
        branch0 = branch0.difference(IDT_data['removal']['Hole_elect0'])   
    branch0 = branch0.difference(removal_center)
    if type(branch0) is shapely_geom.polygon.Polygon:
        patch0 = PolygonPatch(branch0, fc=RED, ec=RED, alpha=0.5, zorder=2)
        ax.add_patch(patch0)
    else:
        tkMessageBox.showwarning(title = 'Warning',message = 'MultiPolygon detected')    
        for polygon in branch0.geoms:
            patch0 = PolygonPatch(polygon, fc=RED, ec=RED, alpha=0.5, zorder=2)
            ax.add_patch(patch0)
    
        
    for polygon in IDT[1]:
        branch1 = branch1.union(polygon)
    branch1 = branch1.difference(removal0)
    if 'Hole_elect1' in IDT_data['removal'].keys():
        branch1 = branch1.difference(IDT_data['removal']['Hole_elect1'])
    branch1 = branch1.difference(removal_center)
    if type(branch1) is shapely_geom.polygon.Polygon:
        patch1 = PolygonPatch(branch1, fc=BLUE, ec=BLUE, alpha=0.5, zorder=2)
        ax.add_patch(patch1)
    else:
        tkMessageBox.showwarning(title = 'Warning',message = 'MultiPolygon detected')    
        for polygon in branch1.geoms:
            patch1 = PolygonPatch(polygon, fc=BLUE, ec=BLUE, alpha=0.5, zorder=2)
            ax.add_patch(patch1)
     
    
    for polygon in reticule:
        patch_ret = PolygonPatch(polygon, fc=GREY, ec=GREY, alpha=0.5, zorder=3)
        ax.add_patch(patch_ret) 
    
    ax.set_title('IDT geometry')
    bounds0 = branch0.bounds
    bounds1 = branch1.bounds
    xrange = [1.1*min([bounds0[0],bounds1[0]]), 1.1*max([bounds0[2],bounds1[2]])]
    yrange = [1.1*min([bounds0[1],bounds1[1]]), 1.1*max([bounds0[3],bounds1[3]])]
    ax.axis([xrange[0],xrange[1], yrange[0], yrange[1]])
    ax.set_aspect(1)
    plt.show(block = True)
    #IDT_data['branch0']=branch0
    #IDT_data['branch1']=branch1

def Polygon2gds(IDT_data):
    layout = gds.core.Layout('LIBRARY')
    cell = gds.core.Cell('Main')
    points =  1e6*numpy.array(IDT_data['branch0'].exterior.coords) #best practice: dimensions in um
    boundaries = gds.core.Boundary(points)
    cell.add(boundaries)
    points = 1e6*numpy.array(IDT_data['branch1'].exterior.coords)
    boundaries = gds.core.Boundary(points)
    cell.add(boundaries)
    reticule = IDT_data['reticule']
    for polygon in reticule:
        points = 1e6*numpy.array(polygon.exterior.coords)
        boundaries = gds.core.Boundary(points)
        cell.add(boundaries)
    layout.add(cell)
    layout.save('output.gds')


def Import_reticule(IDT_data,reticule_size,reticule_filename):
    all_points = SVGT.read_path_from_svg(reticule_filename)
    reticule =[]
    for points in all_points:
        reticule.append(shapely_geom.Polygon(points.T))
    reticule = shapely_geom.MultiPolygon(reticule)
    outbox = reticule.bounds
    dx = outbox[2]-outbox[0]
    dy = outbox[3]-outbox[1]
    d = max([dx,dy])
    x0 = outbox[0]+dx/2
    y0 = outbox[1]+dy/2
    factor = 2*reticule_size/d
    reticule = shapely_affinity.translate(reticule, xoff=-x0, yoff=-y0) 
    reticule = shapely_affinity.scale(reticule, xfact = factor, yfact= factor, origin=(0,0,0))
    IDT_data['reticule'] = reticule

def IDT_union(IDT_data):
    IDT = IDT_data['IDT']
    branch0 = IDT_data['electrodes']['elect0']
    branch1 = IDT_data['electrodes']['elect1']
    removal0 = IDT_data['removal']['removal0']
    removal1 = IDT_data['removal']['removal1']
    #reticule = IDT_data['reticule']
    removal_center = IDT_data['removal']['removal_center']
    for polygon in IDT[0]:
        branch0 = branch0.union(polygon)       
    branch0 = branch0.difference(removal1)
    if 'Hole_elect0' in IDT_data['removal'].keys():
        branch0 = branch0.difference(IDT_data['removal']['Hole_elect0'])
    branch0 = branch0.difference(removal_center)
        
    for polygon in IDT[1]:
        branch1 = branch1.union(polygon)
    branch1 = branch1.difference(removal0)
    if 'Hole_elect1' in IDT_data['removal'].keys():
        branch1 = branch1.difference(IDT_data['removal']['Hole_elect1'])
    branch1 = branch1.difference(removal_center)
    
    IDT_data['branch0']=branch0
    IDT_data['branch1']=branch1
    IDT_merged = IDT[0]+IDT[1]
    IDT_bounds = shapely_geom.MultiPolygon(IDT_merged)
    IDT_bounds = IDT_bounds.convex_hull
    IDT_data['convex_hull'] = IDT_bounds
    
    
def IDT2svg(IDT_data,svg_dwg):
    IDT_bounds = IDT_data['convex_hull']
    branch0 = IDT_data['electrodes']['elect0']
    branch1 = IDT_data['electrodes']['elect1']
    Array = numpy.array(IDT_bounds.exterior.coords)
    svg_dwg  = SVGT.Array2svg(svg_dwg,1e5*Array,'simplify',stroke2 = 'green',fill2 = 'green')
    ArrayE0 = numpy.array(branch0.exterior.coords)
    ArrayE1 = numpy.array(branch1.exterior.coords)
    svg_dwg  = SVGT.Array2svg(svg_dwg,1e5*ArrayE0,'original',stroke2 = 'red',fill2 = 'red')
    svg_dwg  = SVGT.Array2svg(svg_dwg,1e5*ArrayE1,'original',stroke2 = 'blue',fill2 = 'blue')
    
def translate_IDT(IDT_data,x0,y0):
    #useful for the SVG drawing
    IDT_data['convex_hull'] = shapely_affinity.translate(IDT_data['convex_hull'],xoff = x0,yoff = y0)
    IDT_data['electrodes']['elect0'] = shapely_affinity.translate(IDT_data['electrodes']['elect0'],xoff = x0,yoff = y0)
    IDT_data['electrodes']['elect1'] = shapely_affinity.translate(IDT_data['electrodes']['elect1'],xoff = x0,yoff = y0)
    #useful for the union before gds drawing
    IDT = IDT_data['IDT'] 
    for ind in range(len(IDT[0])):
        IDT[0][ind] = shapely_affinity.translate(IDT[0][ind],xoff = x0,yoff = y0)
    for ind in range(len(IDT[1])):
        IDT[1][ind] = shapely_affinity.translate(IDT[1][ind],xoff = x0,yoff = y0)
    IDT_data['reticule'] = shapely_affinity.translate(IDT_data['reticule'],xoff = x0,yoff = y0)
    for key in IDT_data['removal'].keys():
        IDT_data['removal'][key] = shapely_affinity.translate(IDT_data['removal'][key],xoff = x0,yoff = y0)
    #IDT_data['removal']['removal1'] = shapely_affinity.translate(IDT_data['removal']['removal1'],xoff = x0,yoff = y0)
    
def Import_SVG_route(IDT_data):
    route_filename = IDT_data['svg_route']
    all_points = SVGT.read_path_from_svg(route_filename)
    route =[]
    for points in all_points:
        route.append(shapely_geom.Polygon(points.T))
    route = shapely_geom.MultiPolygon(route)
    #outbox = route.bounds
    #dx = outbox[2]-outbox[0]
    #dy = outbox[3]-outbox[1]
    #x0 = outbox[0]+dx/2
    #y0 = outbox[1]+dy/2
    x0svg = 4000
    y0svg = 4000
    factor = 1e-5;
    route = shapely_affinity.translate(route, xoff=-x0svg, yoff=-y0svg) 
    route = shapely_affinity.scale(route, xfact = factor, yfact= factor, origin=(0,0,0))
    IDT_data['route'] = route   
