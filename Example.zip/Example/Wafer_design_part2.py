# -*- coding: utf-8 -*-
"""
Created on Thu Jul 28 19:13:17 2016

@author: Antoine
"""
import cPickle as pickle
import tkFileDialog
from Tweezer_design import IDT_group_toolbox as IDT_gtool
import sys
sys.setrecursionlimit(10000) # 10000 is an example, try with different values

#from Tweezer_design import geometry1 as g0

IDT_group_dir = tkFileDialog.askopenfilename(title = 'Load_project_filename', defaultextension= 'p')

with open(IDT_group_dir, 'rb') as fp:
   IDT_group = pickle.load(fp)
    

#for IDT_data in IDT_group['IDT']:    
#g0.Polygon2gds(IDT_group['IDT'][0])
IDT_gtool.importSVGroute(IDT_group)
#reconstruire un objet 'bigIDT' qui a des peignes +, des peignes -, 
#des électrodes +, une électrode -, et lui faire faire la fusion

IDT_gtool.combineIDT_group(IDT_group)

IDT_gtool.IDT_group2gds(IDT_group)

IDT_gtool.IDT_group2svg(IDT_group)