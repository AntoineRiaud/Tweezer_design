#this is an extension package for shapely to enable a more accurate generation of the IDT geometry
#Shapely is a BSD-licensed Python package for manipulation and analysis of planar geometric objects.
#It is based on the widely deployed GEOS (the engine of PostGIS) and JTS (from which GEOS is ported) libraries.

#class modification methods taken
#from http://block.arch.ethz.ch/blog/2016/07/adding-methods-to-python-classes/

import shapely.geometry as shapely_geom
import numpy
from shapely.ops import cascaded_union
from matplotlib import pyplot
from descartes import PolygonPatch


#These lines make sure that the buffer function is privately conserved
setattr(shapely_geom.Point, "__buffer__", shapely_geom.Point.buffer)
setattr(shapely_geom.LineString, "__buffer__", shapely_geom.LineString.buffer)
setattr(shapely_geom.polygon.LinearRing, "__buffer__", shapely_geom.polygon.LinearRing.buffer)
setattr(shapely_geom.Polygon, "__buffer__", shapely_geom.Polygon.buffer)
setattr(shapely_geom.MultiPoint, "__buffer__", shapely_geom.MultiPoint.buffer)
setattr(shapely_geom.MultiLineString, "__buffer__", shapely_geom.MultiLineString.buffer)
setattr(shapely_geom.MultiPolygon, "__buffer__", shapely_geom.MultiPolygon.buffer)


Nvalues =64

def group(indices):
    d = numpy.diff(indices)
    breaks = 1+numpy.argwhere(d>1.)
    breaks = numpy.append(breaks,len(indices))
    segments = []
    prevbreak = 0
    for i in range(len(breaks)):
        segment = indices[prevbreak:breaks[i]].tolist()
        if len(segment)==0:
            segments.append(segment)
        else:
            segments.append(segment+[segment[-1]+1])
        prevbreak = breaks[i]
    return segments

def group_segments(distance):
    width = numpy.array(distance)
    width = 0.5*(width[0:-1]+width[1:])
    logwidth = numpy.log(width)
    values = numpy.linspace(min(logwidth),numpy.log(1+1e-3)+max(logwidth),Nvalues+1)
    prev_value = -numpy.inf
    segment_groups = []
    for i in range(len(values)):
        boolean = (logwidth >= prev_value)&(logwidth < values[i])
        indices = numpy.argwhere(boolean).flatten()
        segment_groups.append({'value':numpy.exp(values[i]),'segments':group(indices)})
        prev_value = values[i]
    return segment_groups

def Xbuffer(self,distance, **kwargs):
    segment_groups = group_segments(distance)
    try:
        exterior = self.coords[:]
    except NotImplementedError: #self is a polygon
        exterior = self.exterior.coords[:]
        print('warning: only using exterior points')
        interiors = [x.coords[:] for x in self.interiors]
    polygons = []
    for segments in segment_groups: #groups of segments of identical thickness 'value'
        value = segments['value']
        L = []
        for segment in segments['segments']:
            coords = []
            for point in segment:
                try:
                    coords.append(exterior[point])
                except IndexError:
                    coords.append(coords[-1])
            if len(coords)>0:
                L.append(shapely_geom.LineString(coords))
        polygons.append(shapely_geom.MultiLineString(L).__buffer__(value))
    return cascaded_union(polygons)

def buffer(self,distance, **kwargs):
    #complements the usual buffer function to allow for a variable width
    #if distance is a list or another iterable object, the extended buffer is used
    try:
        l = len(distance)
    except TypeError:
        l  = 1
    if l==1:
        #uses the original buffer
        return self.__buffer__(distance,**kwargs)
    else:
        try:
            for component in self:
                return Xbuffer(self,distance, **kwargs)
        except TypeError: #the object is not iterable, thus it is not a collection
            return Xbuffer(self,distance, **kwargs)

#updates the class definition
setattr(shapely_geom.Point, "buffer", buffer)
setattr(shapely_geom.LineString, "buffer", buffer)
setattr(shapely_geom.polygon.LinearRing, "buffer", buffer)
setattr(shapely_geom.Polygon, "buffer", buffer)
setattr(shapely_geom.MultiPoint, "buffer", buffer)
setattr(shapely_geom.MultiLineString, "buffer", buffer)
setattr(shapely_geom.MultiPolygon, "buffer", buffer)



################Example of class modification##############
##def printhi(self,**kwargs):
##    print('hi')
##
##setattr(shapely_geom.Point, "printhi", printhi)
##setattr(shapely_geom.MultiPoint, "printhi", printhi)
##setattr(shapely_geom.linestring.LineString, "printhi", printhi)
##
##if __name__=='__main__':
##point = shapely_geom.Point(0.0, 0.0)
##point.printhi()
##points = shapely_geom.MultiPoint([(0.0, 0.0), (1.0, 1.0)])
##points.printhi()
#####################################################





if __name__=='__main__':
##    point = shapely_geom.Point(0.0, 0.0)
##    point.buffer(1.)
##    point.buffer([1.,2.])
    #a = range(7)
    #a[3:] = range(5,8)
    #print(a)
    #print(group(a))
    print(group_segments([0.1,0.1,0.1,0.3,0.3,0.2,0.2,0.1,0.1,0.5]))
    b = shapely_geom.box(0,0,1,1)
    c = b.exterior.buffer(0.1)
    d = b.exterior.buffer([0.1,0.2,0.3,0.4,0.5])
    fig = pyplot.figure(1, figsize=(10, 4), dpi=90)
    ax = fig.add_subplot(121)
    patch1 = PolygonPatch(c, fc='#6699cc', ec='#6699cc', alpha=0.5, zorder=2)
    ax.add_patch(patch1)
    xrange = [-0.5, 1.5]
    yrange = [-0.5, 1.5]
    ax.set_xlim(*xrange)
    ax.set_ylim(*yrange)
    ax = fig.add_subplot(122)
    patch2 = PolygonPatch(d, fc='#6699cc', ec='#6699cc', alpha=0.5, zorder=1)
    ax.add_patch(patch2)
    xrange = [-0.5, 1.5]
    yrange = [-0.5, 1.5]
    ax.set_xlim(*xrange)
    ax.set_ylim(*yrange)
    pyplot.show()
