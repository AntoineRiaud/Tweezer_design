import numpy
import tkinter as tk
from tkinter import filedialog as FileDialog

def load_material(filename,verbose = False):
    m = {}
    # Reads the material properties from the specified file.  Currently, we fill
    # in the material dictionary as follows:
    #
    m['rho'] = get_Density(filename)   #-> scalar
    if verbose:
        print(m['rho'])
    m['C']  = get_Elasticity(filename) #-> 6x6 matrix
    if verbose:
        print(m['C'])
    m['e'] =  get_PiezoCst(filename)   #-> 3x6 matrix
    if verbose:
        print(m['e'])
    m['eps']=get_permittivity(filename)# 3x3 matrix
    if verbose:
        print(m['eps'])
    #   m['q']                 -> 3x6 matrix
    #   m['mu']                -> 3x3 matrix

    return m


def get_Density(filename):
    # Reads the mass density.
    with open(filename) as f:
        myline = f.readline()
        while (type(myline) is str) and not (myline.strip() == '$Density'):
            myline = f.readline()
        myline = f.readline()
        if type(myline) is str:
            rho = float(myline)
            if not f.readline().strip() == '$EndDensity':
                raise IOError('Material file has a corrupt $Density section.')
    return rho



def get_Elasticity(filename):
    # Reads the (symmetric) stiffness tensor.
    with open(filename) as f:
        myline = f.readline()
        while (type(myline) is str) and not (myline.strip() == '$LinearElasticConstants'):
            myline = f.readline()
        myline = f.readline()
        if type(myline) is str:
            C = numpy.zeros([6,6])
            for row in range(6):
                #excludes the stars
                coefs = myline.split('*')[-1].split()
                C[row,row:] = map(float,coefs)
                myline = f.readline()
            # Creates symmetric stiffness tensor.
            C=C+numpy.triu(C,1).T
            if not myline.strip() == '$EndLinearElasticConstants':
                raise IOError('Material file has a corrupt $LinearElasticConstants section.')
        return C

def get_PiezoCst(filename):
    # Read the piezoelectric stress tensor.
    with open(filename) as f:
        myline = f.readline()
        while (type(myline) is str) and not (myline.strip() == '$PiezoelectricStressConstants'):
            myline = f.readline()
        myline = f.readline()    
        if type(myline) is str:
            e = numpy.zeros([3,6]);
            for row in range(3):  
                e[row,:] = map(float,myline.split());
                myline = f.readline()
            if not myline.strip() == '$EndPiezoelectricStressConstants':
                raise IOError('Material file has a corrupt $PiezoelectricStressConstants section.')
    return e

def get_permittivity(filename):
    # Read the permittivity.
    with open(filename) as f:
        myline = f.readline()
        while (type(myline) is str) and not (myline.strip() == '$Permittivity'):
            myline = f.readline()
        myline = f.readline()
        if type(myline) is str:
            epsilon = numpy.zeros([3,3])
            for row in range(3):
                #excludes the stars
                coefs = myline.split('*')[-1].split()
                epsilon[row,row:] = map(float,coefs)
                myline = f.readline()
            # Creates symmetric permittivity tensor.
            epsilon=epsilon+numpy.triu(epsilon,1).T
        if not myline.strip() == '$EndPermittivity':
            raise IOError('Material file has a corrupt $Permittivity section.')
    return epsilon

def Voigt2tensor(voigt_tensor):
    s = list(voigt_tensor.shape)
    sTensor = []
    for dim in s:
        if dim==6:
            sTensor=sTensor+[3,3]
        else:
            sTensor.append(dim)
    #print(sTensor)
    Tensor = numpy.zeros(sTensor) #defines the size
    for indexVoigt in range(voigt_tensor.size):
        multi_index_voigt = numpy.unravel_index(indexVoigt,s,order='F')
        multi_index_tensor = indexVoigt2indexTensor(multi_index_voigt,s)
        for index_tensor in multi_index_tensor:
            Tensor[tuple(index_tensor)]=voigt_tensor[multi_index_voigt]
    return Tensor
        

def indexVoigt2indexTensor(indexVoigt,shapeVoigt):
    mapVoigt = [[[0,0]],
                [[1,1]],
                [[2,2]],
                [[2,1],[1,2]],
                [[2,0],[0,2]],
                [[0,1],[1,0]]]
    list_indexTensor = [[]]
    for dim in range(len(indexVoigt)):
        if shapeVoigt[dim]==6:
            local_indices = mapVoigt[indexVoigt[dim]]
            newlist_indexTensor = []
            for index_Tensor in list_indexTensor:
                for index in local_indices:
                    newlist_indexTensor.append(index_Tensor+index)
            list_indexTensor = newlist_indexTensor
        else:
            for index_Tensor in list_indexTensor:
                index_Tensor.append(indexVoigt[dim])
    return list_indexTensor
    

def load_material_gui(material_filename=None):
    try:
        m = load_material(material_filename,verbose=False)
    except:
        print('error loading the material for BAW')
        if material_filename==None:
            print('no material specified, please use manual selection.')
        else:
            print('material %s not found, please use manual selection.' %material_filename)
        root = tk.Tk()
        root.withdraw()
        file_path = tkFileDialog.askopenfilename(title='Select material',defaultextension = 'dat')
        m = load_material(file_path,verbose=False)
    return m

#m = load_material_gui()
#print('Voigt')
#print(m['e'])
#C = Voigt2tensor(m['e'])
#print('Tensor')
#print(C)
