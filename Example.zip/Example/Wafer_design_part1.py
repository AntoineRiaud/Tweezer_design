#import goes here
from Tweezer_design import geometry1 as g0
import numpy
import math
import cPickle as pickle
from Tweezer_design import IDT_group_toolbox as IDT_gtool
#import matplotlib.pyplot as plt
#from Tweezer_design.Polygon2array import Polygon2Array
#from scipy.io import savemat

#to remove
#import shapely.geometry as shapely_geom
#from figures import BLUE, RED, GREY
#from descartes import PolygonPatch
#import matplotlib.pyplot as plt
#import svg_toolbox as SVGT


IDT_group = IDT_gtool.Create_group()

#IDT_gtool.Import_slowness_from_matlab(IDT_group)
#substrate_properties = IDT_group['substrate_properties']


#ax = plt.subplot(111)
#ax.plot(psi.tolist(), numpy.angle(a).tolist(), color='r', linewidth=3)
#ax.axis([min(psi),max(psi), min(numpy.angle(a)), max(numpy.angle(a))])
#ax.grid(True)
#ax.set_title("coupling coefficient", va='bottom')
#plt.show()   

IDT_gtool.Import_IDT_parameters(IDT_group)

N_IDT = len(IDT_group['IDT'])
angle_position_IDT = 0.

for IDT in IDT_group['IDT']:
    substrate_properties = IDT['parameters']['slowness_substrate']
    s_Ray = substrate_properties['s_Ray']
    psi = substrate_properties['psi'] #ranges from 0 to pi
    a = substrate_properties['a']
    psi,index = numpy.unique(numpy.hstack([psi,math.pi+psi]),return_index = True) #ranges from 0 to 2pi
    s_Ray = numpy.hstack([s_Ray,s_Ray])
    s_Ray = s_Ray[index]
    a = numpy.hstack([a,numpy.sign(a[0])*numpy.sign(a[-1])*a])
    a = a[index]
    angle_position_IDT = angle_position_IDT+2*numpy.pi/N_IDT
    l = int(numpy.round(IDT['parameters']['l']))
    N_turns = int(numpy.round(IDT['parameters']['N_turns']))
    freq = IDT['parameters']['freq']
    target_size = IDT['parameters']['target_size']
    electrodes_thickness_ratio =  IDT['parameters']['electrodes_thickness_ratio']
    gap_ratio = IDT['parameters']['gap_ratio']
    z = IDT['parameters']['z']
    electrodes_angle = IDT['parameters']['electrodes_angle']
    slowness = IDT['parameters']['slowness']
    electrode_type = IDT['parameters']['electrode_type']
    reticule_filename = IDT['parameters']['reticule_filename']
    branch_type = IDT['parameters']['branch_type']
    branch_angle = {'straight':0,'shifted':90}
    R0_array = 25e-3
    x_offset = R0_array*numpy.cos(angle_position_IDT)
    y_offset = R0_array*numpy.sin(angle_position_IDT)
    IDT['x_offset'] = x_offset
    IDT['y_offset'] = y_offset
    removal_thickness_ratio = electrodes_thickness_ratio+2*gap_ratio
    omega = 2*numpy.pi*freq
    
    mu_0 = g0.Degeneration_correction(z,slowness,s_Ray,psi)
    lambda_approx = 1/(freq*numpy.mean(s_Ray))
    electrodes_thickness = electrodes_thickness_ratio*lambda_approx*g0.thickness_factor(electrode_type)
    branch_thickness = electrodes_thickness_ratio*lambda_approx
    removal_thickness = removal_thickness_ratio*lambda_approx
    reticule_size = lambda_approx/2
    
    Theta_struct = g0.Mesh_Theta(target_size,omega,mu_0,s_Ray,N_turns,l,electrodes_angle)
    phi_0 = Theta_struct['phi_0']
    Theta = Theta_struct['Theta']
    
    IDT_data = g0.MasterCurve2Electrodes(electrode_type,phi_0,psi,Theta,mu_0,s_Ray,l,omega,a,lambda_approx)

    g0.Place_Electrodes(l,phi_0,lambda_approx,electrodes_angle,branch_thickness,removal_thickness,IDT_data,electrode_type,electrode_rotate_angle= branch_angle[branch_type])

    g0.Enlarge_IDT(IDT_data,phi_0,electrode_type,lambda_approx)
    
    g0.Import_reticule(IDT_data,reticule_size,reticule_filename)
    
    #g0.Draw_IDT(IDT_data)
    
    g0.IDT_union(IDT_data)
    
    g0.translate_IDT(IDT_data,x_offset,y_offset)
    
    IDT.update(IDT_data)

IDT_gtool.IDTgroup2svg(IDT_group)

IDT_group_dir = IDT_group['IDT_group_dir']

with open(IDT_group_dir+'/data.p', 'wb') as fp:
    pickle.dump(IDT_group, fp)

#IDT_groupArray = Polygon2Array(IDT_group)

#savemat(IDT_group_dir+'/data.mat', IDT_groupArray, appendmat=True, format='5', long_field_names=False, do_compression=False, oned_as='row')