import spherepy
import numpy as np
import math
import scipy.special
import matplotlib.pyplot as plt
from scipy.optimize import broyden1 as solver


class AngSpectrum(spherepy.ScalarCoefs):
    def __init__(self,my_input,lattitude=None,longitude = None,Nmax = None):
        theta = lattitude
        phi = longitude
        if type(my_input) == spherepy.ScalarCoefs:
            self.c = my_input.copy()
        elif type(my_input) == spherepy.ScalarPatternUniform:
            if Nmax==None:
                Nmax = my_input.nrows/2 # Shannon
            self.c = spherepy.spht(my_input,nmax=Nmax,mmax=Nmax)
        else: #it is an numpy.NdArray
            if theta is None and phi is None:
                #phi=np.linspace(0,2*np.pi,my_input.shape[1])
                #theta=np.linspace(0,np.pi,my_input.shape[0])
                pass
            else:
                #checks grid regularity
                s1 = np.std(np.diff(theta))
                s2 = np.std(np.diff(phi))
                if abs(round(1e10*s1)) ==0 and abs(round(1e10*s2)) ==0: #regular array
                        #self.c = spherepy.spht(spherepy.ScalarPatternUniform(my_input))
                        if Nmax == None:
                            Nmax = my_input.shape[0]/2 #Shannon
                        self.c = spherepy.spht(spherepy.ScalarPatternUniform(my_input),nmax=Nmax,mmax=Nmax)
                else:
                    print('the grid is not regular within an accuracy of 1e-10')
                    print('std for theta: '+ str(s1))
                    print('std for phi: '+ str(s2))
                    raise AttributeError
    def __getattr__(self,name):
        try:
            return getattr(self.c,name)
        except AttributeError as e:
            raise AttributeError("AngSpectrum' object has no attribute '%s'" % name)
    
    def evaluate(self,theta,phi):
        f = np.zeros_like(theta,dtype=np.complex128)
        for n in range(self.nmax+1):
            for m in range(-n,n+1):
                #print('n = %i, m = %i' %(n,m))
                f+=self[n,m]*scipy.special.sph_harm(m, n, phi, theta)
        return f

    def der_phi(self):
        cder_phi = AngSpectrum(spherepy.zeros_coefs(self.nmax,self.mmax))
        for n in range(self.nmax+1):
            for m in range(-n,n+1):
                cder_phi[n,m]=1j*m*self[n,m]
        return cder_phi

    def der_theta(self):
        cder_theta = AngSpectrum(spherepy.zeros_coefs(self.nmax,self.mmax))
        for n in range(self.nmax+1):
            for m in range(-n,n+1):
                if n>0 and abs(m)<=(n-1):
                    cder_theta[n-1,m]=cder_theta[n-1,m]+(Nnm(n,m)/Nnm(n-1,m))*(n+1)*(n+m)*self[n,m]/(2*n+1)
                if n<cder_theta.nmax and abs(m)<=(n+1):
                    cder_theta[n+1,m]=cder_theta[n+1,m]-(Nnm(n,m)/Nnm(n+1,m))*n*(n-m+1)*self[n,m]/(2*n+1)
        return cder_theta

    @property
    def plot_direct(self):
        theta = np.pi*np.array(range(20))/19. #19 = max(range(20))
        phi = np.pi*np.array(range(40))/20.
        phi,theta = np.meshgrid(phi,theta)
        f = spherepy.ScalarPatternUniform(self.evaluate(theta,phi))
        spherepy.plot_sphere_mag(f)

    @property
    def plot_reciprocal(self):
        spherepy.pcolor_coefs(self)

def Nnm(n,m):
    return np.sqrt((2*n+1)*math.factorial(n-m)/(4*np.pi*math.factorial(n+m)))

def der_phi(f): #phi, N points from 0 to 2pi*(1-1/N), physical convention
    c = spherepy.spht(f,nmax=8,mmax=8)
    cder_phi = spherepy.zeros_coefs(c.nmax,c.mmax)
    for n in range(c.nmax+1):
        for m in range(-n,n+1):
            cder_phi[n,m]=1j*m*c[n,m]
    Ncols,Nrows=f.shape
    fder_phi = spherepy.ispht(cder_phi,ncols=Ncols,nrows=Nrows)
    return fder_phi
def der_theta(f): #theta from 0 to pi, physical convention
    c = spherepy.spht(f,nmax=8,mmax=8)
    cder_theta = spherepy.zeros_coefs(c.nmax,c.mmax)
    for n in range(c.nmax+1):
        for m in range(-n,n+1):
            if n>0 and abs(m)<=(n-1):
                cder_theta[n-1,m]=cder_theta[n-1,m]+(n+1)*(n+m)*c[n,m]/(2*n+1)
            if n<cder_theta.nmax and abs(m)<=(n+1):
                cder_theta[n+1,m]=cder_theta[n+1,m]-n*(n-m+1)*c[n,m]/(2*n+1)
    Ncols,Nrows=f.shape
    fder_theta = spherepy.ispht(cder_theta,ncols=Ncols,nrows=Nrows)
    return fder_theta

def residual(x,cder_phi,cder_theta):
    res = [cder_phi.evaluate(x[0].real,x[1].real),cder_theta.evaluate(x[0].real,x[1].real)]
    return res


if __name__ == "__main__":

    n = 1
    m = 1
    phi = np.pi*np.array(range(20))/19. #19 = max(range(20))
    theta = np.pi*np.array(range(40))/20.
    #theta = theta[0:-1]
    theta,phi = np.meshgrid(theta,phi)

    a = np.real(scipy.special.sph_harm(m, n, theta, phi))
    plt.imshow(a)
    plt.show()

    f = spherepy.ScalarPatternUniform(a)
    #plt.imshow(np.real(f.cdata))
    #plt.show()
    spherepy.plot_sphere_mag(f)
    c = spherepy.spht(f,nmax=8,mmax=8)
    spherepy.pretty_coefs(c)
    spherepy.pcolor_coefs(c)

    c3 = AngSpectrum(c)
    f3 = spherepy.ScalarPatternUniform(c3.evaluate(theta, phi))
    c3b = AngSpectrum(f3)
    c3c = AngSpectrum(f3.array)
    spherepy.plot_sphere_mag(f3)
    cder_phi = c3.der_phi()
    spherepy.pretty_coefs(cder_phi)
    cder_theta = c3.der_theta()
    spherepy.pretty_coefs(cder_theta)

    x0 = np.array([0,0],dtype=float)
    sol = solver(lambda x: residual(x,cder_phi,cder_theta), x0, verbose=1)
    
    c2 = spherepy.zeros_coefs(8,8)
    c2[n,m]=1
    spherepy.pcolor_coefs(c2)
    f2 = spherepy.ispht(c2,nrows=20, ncols=40)
    spherepy.plot_sphere_mag(f2)

    spherepy.plot_sphere_mag(der_theta(f2))
    spherepy.plot_sphere_mag(der_phi(f2))
    plt.imshow(np.real(der_theta(f2).cdata))
    plt.show()
